class RuntimeData:
    pass