class RuntimeData:
    pass

class Clazzes:
    classes = {}
    pass