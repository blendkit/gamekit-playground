#import sys
#sys.path.append("/home/ttrocha/_dev/extprojects/blender-git/build_linux/bin/2.76/scripts/addons/game_gamekit")

import bpy,re
from bpy.types import NodeTree, Node, NodeSocket
import runtimedata
import SpaceContext 
from bpy.app.handlers import persistent
import traceback
from asyncio import coroutine, sleep, Task, wait_for
import asynciobridge
import NodetreeDebugger
import bpy.utils.previews, os
from bpointers import *
import runtime

# Implementation of custom nodes from Python

class DefaultMap(bpy.types.PropertyGroup):
    value=bpy.props.StringProperty()

try: 
    bpy.utils.unregister_class(bpy.types.DefaultMap)
except:
    pass
bpy.utils.register_class(DefaultMap)

preview_collections = {}

def enum_previews_from_directory_items(self, context):
    """EnumProperty callback"""
    enum_items = []

    if context is None:
        return enum_items

    space = context.space_data
    if space is None:
        return enum_items;
    
    nodetree = space.node_tree
    directory = nodetree.my_previews_dir

    # Get the preview collection (defined in register func).
    pcoll = getPCOLL(directory)

    if pcoll and directory == pcoll.my_previews_dir:
        return pcoll.my_previews

    print("Scanning directory: %s" % directory)

    if directory and os.path.exists(directory):
        # Scan the directory for png files
        image_paths = []
        
        list_files = os.listdir(directory)
        list_files.sort()
        for fn in list_files:
            if fn.lower().endswith(".png"):
                image_paths.append(fn)

        for i, name in enumerate(image_paths):
            # generates a thumbnail preview for a file.
            filepath = os.path.join(directory, name)
            thumb = pcoll.load(filepath, filepath, 'IMAGE')
            enum_items.append((name, name, "", thumb.icon_id, i))
            #print ( ("Create (%s,%s,'',%s,%i)") % (name,name,str(thumb.icon_id),i) )

    pcoll.my_previews = enum_items
    pcoll.my_previews_dir = directory
    return pcoll.my_previews

def getPCOLL(name):
    global preview_collections
    try:
        result = preview_collections[name]
        return result
    except:    
        pcoll = bpy.utils.previews.new()
        pcoll.my_previews_dir = ""
        pcoll.my_previews = ()
        preview_collections[name]=pcoll
        return pcoll

@coroutine
def createDebugTree(treename,debug_treename):
    print("CREATE:" +debug_treename+" from:"+treename)
    if treename[:6]=="debug_" or treename[:6]=="zz____":
        print ("Tried to create invalid debug-tree "+debug_treename)
        return
    
    if (debug_treename not in bpy.data.node_groups):
        tree = bpy.data.node_groups[treename]
        debugClone = tree.copy()
        debugClone.name=debug_treename
    
        frame = debugClone.nodes.new("NodeFrame")
        frame.label="DEBUG " + debug_treename
        frame.label_size=64
        frame.use_custom_color=True
        frame.color=(1.0,0.2,0.2)
        
        for node in debugClone.nodes:
            if not node.parent:
                node.parent=frame
    
runtimedata.RuntimeData.debugRunning = False

#TODO: Pack all this data in a PropertyGroup and put it in the node-tree
bpy.types.Scene.showOptions=bpy.props.BoolProperty(name="Show Options")
bpy.types.NodeTree.show_options=bpy.props.BoolProperty(name="Show Options")
bpy.types.NodeTree.debugPossibleObjects=bpy.props.CollectionProperty(type=bpy.types.DefaultMap) # save all objects that currently use this tree in debugmode
bpy.types.NodeTree.my_previews_dir = bpy.props.StringProperty(
        name="Preview Image Path",
        subtype='DIR_PATH',
        default=""
)

bpy.types.Node.enabled__=bpy.props.BoolProperty(default=True)
bpy.types.Node.bakColor=bpy.props.FloatVectorProperty()
bpy.types.Node.cover_mode = bpy.props.BoolProperty(default=False)
bpy.types.Node.my_previews = bpy.props.EnumProperty(
        items=enum_previews_from_directory_items,
)

bpy.types.Object.gk_nodetree=bpy.props.StringProperty()
bpy.types.World.gk_nodetree = bpy.props.StringProperty() # field for browsing-mode
bpy.types.World.gk_nodetree_browsing = bpy.props.BoolProperty() # browse the trees or select lopic for current obj
bpy.types.World.gk_nodetree_show_ioSockets = bpy.props.BoolProperty(default=False)
bpy.types.World.gk_validNodeTrees = bpy.props.CollectionProperty(type=bpy.types.DefaultMap)

def singlestepToggle(self,context):
    if self.singleStep:
        print("START SINGLESTEP")
        NodetreeDebugger.singleStep("start")
        pass
    else:
        NodetreeDebugger.singleStep("stop")
        print("STOP SINGLESTEP")
        pass

bpy.types.World.singleStep=bpy.props.BoolProperty(update=singlestepToggle)

def removeDebugTrees():
    for nodetree in bpy.data.node_groups:
        if nodetree.name[:6]=="debug_" or nodetree.name[:6]=="zz____":
            print("Removing debug-tree:" + nodetree.name)
            try:
                bpy.data.node_groups.remove(nodetree)
                print ("success")
            except:
                print("fail")
                #on fail at least rename it, so we can start fresh
                if nodetree.name[:6]=="debug_":
                    nodetree.name="zz____"+nodetree.name

def hookDebugMode(self,context):
    world = bpy.data.worlds[0]
    if (world.gk_nodetree_debugmode):
        removeDebugTrees()
        runtimedata.RuntimeData.debugSession={}
        runtimedata.RuntimeData.debugRunning=True 
        asynciobridge.startAsyncServer()
        NodetreeDebugger.startDebugPolling()
        
        print("SET RUNTIME-DEBUG-Data")
    else:
        NodetreeDebugger.stopDebugPolling()
        runtimedata.RuntimeData.debugRunning=False
        
bpy.types.World.gk_nodetree_debugmode = bpy.props.BoolProperty(default=False, update=hookDebugMode)

@persistent
def load_handler(dummy):
    
#     print("Load Handler:", bpy.data.filepath)
#     if (hasattr(runtimedata.RuntimeData,"currentFile") and runtimedata.RuntimeData.currentFile==bpy.data.filepath):
#         print("BLOCK!")
#         return
        
    runtimedata.RuntimeData.currentFile = bpy.data.filepath
    bpy.data.worlds[0].gk_nodetree_debugmode=False
    # try to delete debug-trees
    removeDebugTrees()
    updateValidNodeTrees()
    
    runtimedata.RuntimeData.asycBridgeRunning=False    
    #asynciobridge.startAsyncServer()
    
    runtimedata.RuntimeData.runtime = runtime.BlenderRuntime()
    runtimedata.RuntimeData.runtime.processNodetrees()

    def getLogic(node):
        return runtimedata.RuntimeData.runtime.getLogic(node.bpid)

    bpy.types.Node.logic = property(getLogic)
    
    def getNodetreePointer(nt):
        return BPointer.getByID(nt.bpid)
    
    bpy.types.NodeTree.logic = property(getNodetreePointer)
        
    # init the elements. IMPORTANT, because the elements interested will add themselfs to the update-queue
    runtimedata.RuntimeData.runtime.callStartup() 
    @coroutine
    def runtimeCaller():
        if hasattr(runtimedata.RuntimeData,"runtime_running") and runtimedata.RuntimeData.runtime_running:
            return

        runtimedata.RuntimeData.runtime_running = True

        runtimedata.RuntimeData.runtime.tick()
        yield from sleep(0.1)
        runtimedata.RuntimeData.runtime.tick()

        while runtimedata.RuntimeData.runtime_running:
            print ("RUNTIME DATA-TICK")
            runtimedata.RuntimeData.runtime.tick()
            yield from sleep(3) 
        print("LEFT TICK-LOOP")
            
    Task(runtimeCaller())
    
bpy.app.handlers.load_post.append(load_handler)

def updateValidNodeTrees():
    print ("UPDATE VALID TREES")
    validTrees = bpy.data.worlds[0].gk_validNodeTrees
    i = 0
    for validTree in validTrees:
        if validTree.name not in bpy.data.node_groups: # a fromer valid tree disappeared? remove it
            validTrees.remove(i)
        i = i + 1
            
    for tree in bpy.data.node_groups: # search for valid groups that are not yet added
        if tree.name[:6]!="debug_" and tree.name[:6]!="zz____" and validTrees.find(tree.name)==-1:
            addValidTree(tree.name)
            
def addValidTree(validTreeName):
    validTrees = bpy.data.worlds[0].gk_validNodeTrees
    newItem = validTrees.add()
    newItem.name = validTreeName
    print("ADDED VALID TREE:" + newItem.name)
            
class SocketGroup(bpy.types.PropertyGroup):
    name = bpy.props.StringProperty()
    extName = bpy.props.StringProperty()
    isInput = bpy.props.BoolProperty()

try:
    bpy.utils.unregister_class(bpy.types.SocketGroup)
except:
    pass
bpy.utils.register_class(SocketGroup)   

class GamekitOperator(bpy.types.Operator):
    """Tooltip"""
    bl_idname = "object.gamekit_operator"
    bl_label = "Create Nodetree"

    op_treename = bpy.props.StringProperty(name="Treename:")

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):
        scene = context.scene
        name = self.op_treename
        addValidTree(name)
        bpy.data.node_groups.new(name,"Gamekit")
        return {'FINISHED'}
    
    def invoke(self, context, event):
        wm = context.window_manager
        result = wm.invoke_props_dialog(self)
        return result    

class GamekitUpdateTreeOperator(bpy.types.Operator):
    """update trees"""
    bl_idname = "object.gamekit_updatetrees_operator"
    bl_label = "Update Tree-Signatur"

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        for tree in bpy.data.node_groups.values():
            if tree.bl_idname=="Gamekit":
                print ("Gamekit-Nodetree:"+tree.name)
                # process nodes
                for node in tree.nodes.values():
                    try:
                        node.doUpdate()
                    except:
                        pass
                    
        return {'FINISHED'}

try:
    bpy.utils.unregister_class(bpy.types.GamekitUpdateTreeOperator)    
except:
    pass    
bpy.utils.register_class(GamekitUpdateTreeOperator)

class GamekitAddSocketOperator(bpy.types.Operator):
    """Tooltip"""
    bl_idname = "gamekit.addsocket"
    bl_label = "add socket to node"

    op_inputSocket = bpy.props.BoolProperty(name="InputSocket")
    op_socketName = bpy.props.StringProperty(name="SocketName:")
    op_type = bpy.props.EnumProperty(items=[("bool","bool","bool"),("string","string","string"),("float","float","float"),("int","int","int")
                                            ,("object","object","object"),("vec3","vec3","vec3"),("color","color","color")])
    @classmethod
    def poll(cls, context):
        space = context.space_data
        return space.type == 'NODE_EDITOR'

    def execute(self, context):
        space = context.space_data
        node_tree = space.node_tree
        node_active = context.active_node
        
        print ("ActiveNode:"+node_active.name)
        
        socketType = "NodeTreeBOOL"
        if self.op_type == "float":
            socketType = "NodeTreeFLOAT"
        elif self.op_type == "int":
            socketType = "NodeTreeINT"
        elif self.op_type == "string":
            socketType = "NodeTreeSTRING"
        elif self.op_type == "object":
            socketType = "NodeTreeObject"
        elif self.op_type == "vector":
            socketType = "NodeTreeVEC3"
        elif self.op_type == "color":
            socketType = "NodeTreeCOLOR"
        
        if (self.op_inputSocket):
            node_active.inputs.new(socketType,self.op_socketName)
            newS = node_active.NEW_IN_SOCKETS.add()
            newS.isInput=True
            newS.name=self.op_socketName
        else:
            node_active.outputs.new(socketType,self.op_socketName)
            newS = node_active.NEW_OUT_SOCKETS.add()
            newS.isInput=False
            newS.name=self.op_socketName
        
        self.op_type="bool"
        self.op_socketName="";
                    
        return {'FINISHED'} 
    
    def invoke(self, context, event):
        wm = context.window_manager
        result = wm.invoke_props_dialog(self)
        return result
        
try:
    bpy.utils.unregister_class(bpy.types.GamekitAddSocketOperator)    
except:
    pass    
bpy.utils.register_class(GamekitAddSocketOperator)

class GamekitRemoveSocketOperator(bpy.types.Operator):
    """Tooltip"""
    bl_idname = "gamekit.removesocket"
    bl_label = "remove socket to node"

    isInputSocket = bpy.props.BoolProperty();
        
    @classmethod
    def poll(cls, context):
        space = context.space_data
        return space.type == 'NODE_EDITOR'

    def execute(self, context):
        space = context.space_data
        node_tree = space.node_tree
        node_active = context.active_node

        print ("Removed:"+node_active.inputSockets)
        
        if (self.isInputSocket):
            node_active.inputs.remove(node_active.inputs[node_active.inputSockets])
            node_active.NEW_IN_SOCKETS.remove(node_active.NEW_SOCKETS.find(node_active.inputSockets))
        else:
            node_active.outputs.remove(node_active.outputs[node_active.outputSockets])
            node_active.NEW_OUT_SOCKETS.remove(node_active.NEW_SOCKETS.find(node_active.outputSockets))
     
        return {'FINISHED'} 
    
try:
    bpy.utils.unregister_class(bpy.types.GamekitRemoveSocketOperator)    
except:
    pass    
bpy.utils.register_class(GamekitRemoveSocketOperator)

class GamekitSelectAllOperator(bpy.types.Operator):
    """Tooltip"""
    bl_idname = "gamekit.select_all_of_this_type"
    bl_label = "Select all nodes of this type"   
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
        
    @classmethod
    def poll(cls,context):
        return context.active_node is not None
    
    def execute(self,context):
        nodetree = context.space_data.node_tree
        current_node = context.active_node
        current_type = current_node.bl_idname
        
        for node in nodetree.nodes:
            if node.bl_idname == current_type:
                node.select=True
            else:
                node.select=False
                
        return {'FINISHED'} 
                
try:
    bpy.utils.unregister_class(bpy.types.GamekitSelectAllOperator)    
except:
    pass    
bpy.utils.register_class(GamekitSelectAllOperator)   

class GamekitToggleEnableOperator(bpy.types.Operator):
    """Tooltip"""
    bl_idname = "gamekit.enable_nodes"
    bl_label = "(de)activate all selected nodes"   
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    
    enableMode = bpy.props.BoolProperty()
    
    @classmethod
    def poll(cls,context):
        return context.active_node is not None
    
    def execute(self,context):
        for node in context.selected_nodes:
            if (self.enableMode and not node.enabled__):
                node.use_custom_color=True
                node.color=node.bakColor
            elif (not self.enableMode and node.enabled__):
                node.use_custom_color=True
                node.bakColor = node.color
                node.color = (1,0,0)
                
            node.enabled__ = self.enableMode
            
        return {'FINISHED'}
try:
    bpy.utils.unregister_class(bpy.types.GamekitToggleEnableOperator)    
except:
    pass    
bpy.utils.register_class(GamekitToggleEnableOperator)  

class GamekitToggleOperator(bpy.types.Operator):
    """Tooltip"""
    bl_idname = "gamekit.toggler"
    bl_label = "toggle some values"   
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    
    mode = bpy.props.IntProperty()
    # 0 = toggle ioSocket
    
    @classmethod
    def poll(cls,context):
        return True
    
    def execute(self,context):
        if self.mode == 0:
            bpy.data.worlds[0].gk_nodetree_show_ioSockets = not bpy.data.worlds[0].gk_nodetree_show_ioSockets
             
        return {'FINISHED'}

    def draw(self,context):
        layout = self.layout
        layout.props(self,"mode",text="MIXI")
try:
    bpy.utils.unregister_class(bpy.types.GamekitToggleOperator)    
except:
    pass    
bpy.utils.register_class(GamekitToggleOperator) 

######### PANEL ##########################################################################
    
class GamekitPanel(bpy.types.Panel):
    """Creates a Panel in the scene context of the properties editor"""
    bl_label = "Gamekit_NodeTree"
    #bl_idname = "SCENE_PT_layout"
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    bl_context = "object"
    
    def onupdate(self, context):
        return None   
    
    @classmethod
    def poll(cls,ctx):
        # only show panel if current tree is of type 'Gamekit'
        tree = ctx.space_data.node_tree
        return not tree or tree.rna_type.identifier == 'Gamekit'

    def draw(self, context):
        layout = self.layout

        spaceContext = SpaceContext.getCurrentSpaceContext(context)
        scene = context.scene
        obj = context.object
        tree = None
        if spaceContext and spaceContext.logicTreeBrowsing and spaceContext.logicTreeName!="" and bpy.data.node_groups.find(spaceContext.logicTreeName)!=-1:
            tree = bpy.data.node_groups[spaceContext.logicTreeName]
        else:
            tree = context.space_data.node_tree
        
        # Create a simple row.

        # Different sizes in a row
        layout.label(text="Tools:")

        world = bpy.data.worlds[0]

        layout.prop(world,"gk_nodetree_debugmode","Node-Tree debugmode")

        #bpy.ops.utils.spacecontext('EXEC_DEFAULT')
        
        #signatur = SpaceContext.getCurrentSpaceSignature(context)

        layout.prop(world,"singleStep","SingleStep debugging")
        
        if (world.singleStep):
            layout.operator("debugger.singlestep")
        
        if spaceContext:
            layout.prop(spaceContext,"logicTreeBrowsing","Node-Tree browsing")
        else: 
            layout.label(text="SIGN")
            #bpy.ops.utils.spacecontext('INVOKE_DEFAULT')
            layout.operator("utils.spacecontext")

        searchName = "Obj Logic:"
        if spaceContext and spaceContext.logicTreeBrowsing:
            searchName="Browse:"  
            #for now go back to this view, using gk_validNodeTrees is not stable enough
            layout.prop_search(spaceContext,"logicTreeName",bpy.data,"node_groups")
#            layout.prop_search(spaceContext,"logicTreeName",bpy.data.worlds[0],"gk_validNodeTrees",searchName)
#            layout.template_ID(context.space_data, "node_tree", new="node.new_node_tree")
        else:
            if obj:
                layout.prop_search(obj,"gk_nodetree",bpy.data,"node_groups",searchName)
                #layout.prop_search(obj,"gk_nodetree",bpy.data.worlds[0],"gk_validNodeTrees",searchName)

        if world.gk_nodetree_debugmode and spaceContext:
            if spaceContext.logicTreeBrowsing and tree  :
                layout.prop_search(spaceContext,"debugObject",tree,"debugPossibleObjects")
            else:
                layout.label("debugObject: "+obj.name)
        else:
            layout.label("NO DEBUGMODE AND SPCTX")

        layout.operator("gamekit.select_all_of_this_type")
        layout.operator("gamekit.enable_nodes","activate selected nodes").enableMode=1
        layout.operator("gamekit.enable_nodes","deactivate selected nodes").enableMode=0
        layout.operator("scene.gamekit_start_game", text="Start Game", icon='GAME')  
                       
        layout.prop(scene,"showOptions")
        if scene.showOptions:
            layout.operator("object.gamekit_operator")
            layout.operator("object.gamekit_updatetrees_operator")
            layout.operator("gamekit.addsocket")
            layout.operator("gamekit.toggler",text="show/hide ioSocket-Flag").mode=0
            if tree:
                layout.prop(tree, "my_previews_dir")
                
            row = layout.row()
            row.operator("gamekit.asyncio_start")
            row.operator("gamekit.asyncio_stop")
            
            layout.operator("gamekit.removeprintdebug")

# Derived from the NodeTree base type, similar to Menu, Operator, Panel, etc.
class Gamekit(NodeTree):
    # Description string
    '''A custom node tree type that will show up in the node editor header'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'Gamekit'
    # Label for nice name display
    bl_label = 'GameKit-TreeNode'
    # Icon identifier
    bl_icon = "NODETREE"

    @classmethod
    def get_from_context(cls, context):
        spaceContext = SpaceContext.getCurrentSpaceContext(context)
        world = bpy.data.worlds[0]
        browseMode = spaceContext and spaceContext.logicTreeBrowsing
        ob = context.object
        if browseMode:
            ob = world
        
        space_data = context.space_data
        
        if ob is not None:
            #obj = bpy.data.objects[ob.name]
            if not browseMode:
                if "gk_nodetree" in ob and ob.gk_nodetree!="":
                    treename = ob["gk_nodetree"]
                    
                    if runtimedata.RuntimeData.debugRunning and treename[:6]!="debug_":
                        debug_treename = "debug_"+treename+"_"+ob.name
                        if debug_treename not in bpy.data.node_groups:
                            print("CALL:"+treename+" - "+debug_treename)
                            Task(createDebugTree(treename,debug_treename))
                            print ("CREATED NEW NODETREE:"+debug_treename)
                        treename = debug_treename
                            
                    if treename in bpy.data.node_groups:
                        tree = bpy.data.node_groups[treename]
                        return tree, tree, ob
                    else:
                        return space_data.node_tree,space_data.node_tree,ob 
                return None,None,None
            else:
                tree = None
                if spaceContext:
                    if spaceContext.logicTreeName=="" or bpy.data.node_groups.find(spaceContext.logicTreeName)==-1:
                        return None,None,None
                    
                    tree = bpy.data.node_groups[spaceContext.logicTreeName]
                    treename = spaceContext.logicTreeName
                    
                    if not runtimedata.RuntimeData.debugRunning:
                        #print ("NOT IN DEBUGMODE!")
                        return tree,tree,ob 
                    
                    if runtimedata.RuntimeData.debugRunning and spaceContext.debugObject!="": 
                        #ob = bpy.data.objects[spaceContext.debugObject]
                        debug_treename = "debug_"+treename+"_"+spaceContext.debugObject
                        print ("BROWSING debugtree:" + debug_treename)
                        if debug_treename not in bpy.data.node_groups:
                            print("TRY TO CREATE!")
                            Task(createDebugTree(treename,debug_treename))
                        
                        print("f1")
                        if debug_treename in bpy.data.node_groups:
                            print("f2")
                            dbgtree = bpy.data.node_groups[debug_treename]
                            return dbgtree, dbgtree, ob
                        else:
                            print("f3")
                            return tree,tree,ob                         
                    print("f4")    
                    return tree,tree,ob   
                return space_data.node_tree,space_data.node_tree,ob
            return context.space_data.node_tree, context.space_data.node_tree, None

class NodeTreeObject(NodeSocket):
    # Description string
    '''Custom node socket type'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    # Label for nice name display
    dataVisible = bpy.props.BoolProperty(default=True)
    value = bpy.props.BoolProperty()
    isIOSocket = bpy.props.BoolProperty()
    ioSocketName = bpy.props.StringProperty()
    # Optional function for drawing the socket input value
    def draw(self, context, layout, node, text):
        layout.label(text)        
            
        if bpy.data.worlds[0].gk_nodetree_show_ioSockets:
            layout.prop(self,"isIOSocket")
            if (self.isIOSocket):
                layout.prop(self,"ioSocketName")
    # Socket color
    def draw_color(self, context, node):
        if self.isIOSocket:
            return (1.0, 0.1, 0.1, 0.9)
        else:
            return (0.3,0.55,0.19,1.0)

# Custom socket type
class NodeTreeBOOL(NodeSocket):
    # Description string
    '''Custom node socket type'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    # Label for nice name display
    dataVisible = bpy.props.BoolProperty(default=True)
    value = bpy.props.BoolProperty()
    isIOSocket = bpy.props.BoolProperty()
    ioSocketName = bpy.props.StringProperty()
    # Optional function for drawing the socket input value
    def draw(self, context, layout, node, text):
        if self.is_output or self.is_linked or not self.dataVisible:
            layout.label(text)        
        else:
            layout.prop(self, "value",text=text)
            
        if bpy.data.worlds[0].gk_nodetree_show_ioSockets:
            layout.prop(self,"isIOSocket")
            if (self.isIOSocket):
                layout.prop(self,"ioSocketName")
    # Socket color
    def draw_color(self, context, node):
        if bpy.data.worlds[0].gk_nodetree_debugmode:
            if self.value:
                return (0.0,1.0,0.0,1.0)
            else:
                return (1.0,.0,0.0,1.0)
                
        else:
            if self.isIOSocket:
                return (1.0, 0.1, 0.1, 0.9)
            else:
                return (0.5,0.8,0.0,1.0)
        
class NodeTreeSTRING(NodeSocket):
    # Description string
    '''Custom node socket type'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    # Label for nice name display
    dataVisible = bpy.props.BoolProperty(default=True)
    value = bpy.props.StringProperty()
    isIOSocket = bpy.props.BoolProperty()
    ioSocketName = bpy.props.StringProperty()
    # Optional function for drawing the socket input value
    def draw(self, context, layout, node, text):
        if bpy.data.worlds[0].gk_nodetree_debugmode:
            layout.prop(self,"value",text=text)
        else:        
            if self.is_output or self.is_linked or not self.dataVisible:
                layout.label(text)        
            else:
                layout.prop(self, "value",text=text)
            
        if bpy.data.worlds[0].gk_nodetree_show_ioSockets:
            layout.prop(self,"isIOSocket")
            if (self.isIOSocket):
                layout.prop(self,"ioSocketName")
    # Socket color
    def draw_color(self, context, node):
        if self.isIOSocket:
            return (1.0, 0.1, 0.1, 0.9)
        else:
            return (0.3,0.2,0.6,1.0)        

class NodeTreeINT(NodeSocket):
    # Description string
    '''Custom node socket type'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    # Label for nice name display

    dataVisible = bpy.props.BoolProperty(default=True)
    value = bpy.props.IntProperty()
    isIOSocket = bpy.props.BoolProperty()
    ioSocketName = bpy.props.StringProperty()
    # Optional function for drawing the socket input value
    def draw(self, context, layout, node, text):
        if bpy.data.worlds[0].gk_nodetree_debugmode:
            layout.prop(self,"value",text=text)
        else:
            if self.is_output or self.is_linked or not self.dataVisible:
                layout.label(text)        
            else:
                layout.prop(self, "value",text=text)
            
        if bpy.data.worlds[0].gk_nodetree_show_ioSockets:
            layout.prop(self,"isIOSocket")
            if (self.isIOSocket):
                layout.prop(self,"ioSocketName")
    # Socket color
    def draw_color(self, context, node):
        if self.isIOSocket:
            return (1.0, 0.1, 0.1, 0.9)
        else:
            return (0.0,0.3,0.8,1.0)

class NodeTreeFLOAT(NodeSocket):
    # Description string
    '''Custom node socket type'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    # Label for nice name display
    dataVisible = bpy.props.BoolProperty(default=True)
    value = bpy.props.FloatProperty(precision=3)
    isIOSocket = bpy.props.BoolProperty()
    ioSocketName = bpy.props.StringProperty()
    # Optional function for drawing the socket input value
    def draw(self, context, layout, node, text):
        if bpy.data.worlds[0].gk_nodetree_debugmode:
            layout.prop(self,"value",text=text)
        else:
            if self.is_output or self.is_linked or not self.dataVisible:
                if self.isIOSocket and self.ioSocketName!="":
                    layout.label(self.ioSocketName)
                else:
                    layout.label(text)        
            else:
                if (self.isIOSocket and self.ioSocketName!=""):
                    layout.prop(self, "value",text=self.ioSocketName)
                else:
                    layout.prop(self, "value",text=text)
                
            if bpy.data.worlds[0].gk_nodetree_show_ioSockets:
                layout.prop(self,"isIOSocket")
                if (self.isIOSocket):
                    layout.prop(self,"ioSocketName")
    # Socket color
    def draw_color(self, context, node):
        if self.isIOSocket:
            return (1.0, 0.1, 0.1, 0.9)
        else:
            return (0.3,0.6,0.9,1.0)
        
class NodeTreeVec3(NodeSocket):
    # Description string
    '''Custom node socket type'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    # Label for nice name display
    dataVisible = bpy.props.BoolProperty(default=True)
    value = bpy.props.FloatVectorProperty(size=3)
    isIOSocket = bpy.props.BoolProperty()
    ioSocketName = bpy.props.StringProperty()
    # Optional function for drawing the socket input value
    def draw(self, context, layout, node, text):
        if bpy.data.worlds[0].gk_nodetree_debugmode:
            layout.prop(self,"value",text=text)
        else:        
            if self.is_output or self.is_linked or not self.dataVisible:
                layout.label(text)        
            else:
                layout.prop(self, "value",text=text)
                
            if bpy.data.worlds[0].gk_nodetree_show_ioSockets:
                layout.prop(self,"isIOSocket")
                if (self.isIOSocket):
                    layout.prop(self,"ioSocketName")
    # Socket color
    def draw_color(self, context, node):
        if self.isIOSocket:
            return (1.0, 0.1, 0.1, 0.9)
        else:
            return (0.0,0.3,0.8,1.0)
        
class NodeTreeCOLOR(NodeSocket):
    # Description string
    '''Custom node socket type'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    # Label for nice name display
    dataVisible = bpy.props.BoolProperty(default=True)
    value = bpy.props.FloatVectorProperty(size=4,subtype="COLOR",min=0.0,max=1.0,precision=3)
    isIOSocket = bpy.props.BoolProperty()
    ioSocketName = bpy.props.StringProperty()
    # Optional function for drawing the socket input value
    def draw(self, context, layout, node, text):
        if self.is_output or self.is_linked or not self.dataVisible:
            layout.label(text)        
        else:
            layout.prop(self, "value",text=text)
            
        if bpy.data.worlds[0].gk_nodetree_show_ioSockets:
            layout.prop(self,"isIOSocket")
            if (self.isIOSocket):
                layout.prop(self,"ioSocketName")
        # Socket color
    def draw_color(self, context, node):
        if self.isIOSocket:
            return (1.0, 0.1, 0.1, 0.9)
        else:
            return (0.25,0.9,0.3,1.0)        

# Mix-in class for all custom nodes in this tree type.
# Defines a poll function to enable instantiation.
class GamekitNode:
    @classmethod
    def poll(cls, ntree):
        return ntree.bl_idname == 'Gamekit'

################################# NODE ############################################################

# Derived from the Node base type.
class PickRayNode(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''Create a PickRay'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'PickRayNode'
    # Label for nice name display
    bl_label = 'PickRayNode'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    hitProperty = bpy.props.StringProperty(
        name="hitProperty"
        ,default=""
        ,subtype="NONE"
        ,maxlen=0
        ,description="The NODE"
        
        )
    
    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "UPDATE",
"X",
"Y",
"sceneName",

            ]        
    outputsockets=[
             "HIT",
"NOT_HIT",
"HIT_OBJ",
"HIT_POINT",
"HIT_NORMAL",

            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        UPDATE = self.inputs.new('NodeTreeBOOL', "UPDATE")

        X = self.inputs.new('NodeTreeFLOAT', "X")

        Y = self.inputs.new('NodeTreeFLOAT', "Y")

        sceneName = self.inputs.new('NodeTreeSTRING', "sceneName")

        HIT=self.outputs.new('NodeTreeBOOL', "HIT")
        
        NOT_HIT=self.outputs.new('NodeTreeBOOL', "NOT_HIT")
        
        HIT_OBJ=self.outputs.new('NodeTreeSTRING', "HIT_OBJ")
        
        HIT_POINT=self.outputs.new('NodeTreeVec3', "HIT_POINT")
        
        HIT_NORMAL=self.outputs.new('NodeTreeVec3', "HIT_NORMAL")
        
        try:
            PickRayNode_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'PickRayNode',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'PickRayNode',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'PickRayNode',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop(self, "hitProperty")

        try:
            PickRayNode_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop(self, "hitProperty")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            PickRayNode_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return PickRayNode_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "UPDATE" not in keys:
            UPDATE = self.inputs.new('NodeTreeBOOL', "UPDATE")

        if "X" not in keys:
            X = self.inputs.new('NodeTreeFLOAT', "X")

        if "Y" not in keys:
            Y = self.inputs.new('NodeTreeFLOAT', "Y")

        if "sceneName" not in keys:
            sceneName = self.inputs.new('NodeTreeSTRING', "sceneName")

        keys = self.outputs.keys()
      
        if "HIT" not in keys:
            HIT=self.outputs.new('NodeTreeBOOL', "HIT")
        
        if "NOT_HIT" not in keys:
            NOT_HIT=self.outputs.new('NodeTreeBOOL', "NOT_HIT")
        
        if "HIT_OBJ" not in keys:
            HIT_OBJ=self.outputs.new('NodeTreeSTRING', "HIT_OBJ")
        
        if "HIT_POINT" not in keys:
            HIT_POINT=self.outputs.new('NodeTreeVec3', "HIT_POINT")
        
        if "HIT_NORMAL" not in keys:
            HIT_NORMAL=self.outputs.new('NodeTreeVec3', "HIT_NORMAL")
        
# Derived from the Node base type.
class TestNode(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''This node is badass!'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'TestNode'
    # Label for nice name display
    bl_label = 'TestNode'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    ObjectName = bpy.props.StringProperty(
        name="ObjectName"
        ,default="unknown"
        ,subtype="NONE"
        ,maxlen=0
        ,description="The NODE"
        
        )
    
    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    Dir = bpy.props.FloatVectorProperty(
        name="Dir"
        
        ,subtype="NONE"

        ,unit="NONE"
        ,precision=0
     
        ,size=2
   
        ,description="no desc"

        )

    Fac = bpy.props.FloatProperty(
        name="Fac"

        ,default=10.95
        
        ,subtype="NONE"

        ,unit="NONE"
        ,precision=2
     
        ,description="no desc"

        )

    Size = bpy.props.IntProperty(
        name="Size"

        ,default=95
        
        ,subtype="NONE"
     
        ,description="no desc"

        )

    test = bpy.props.FloatVectorProperty(
        name="test"
        
        ,subtype="NONE"

        ,unit="NONE"
        ,precision=0
     
        ,size=2
   
        ,description="no desc"

        )
  
    Mode_items = [
        ("fast", "fast", "Fast Mode"),
        ("slow", "slow", "Slow Mode"),
        ("ufast", "UltraFast", "Ultrafast Mode"),

    ]
    Mode = bpy.props.EnumProperty(description="null", items=Mode_items, default="slow")
    
    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "sUpdate",

            ]        
    outputsockets=[
             "timer",

            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        sUpdate = self.inputs.new('NodeTreeBOOL', "sUpdate")

        timer=self.outputs.new('NodeTreeFLOAT', "timer")
        
        try:
            TestNode_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'TestNode',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'TestNode',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'TestNode',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop(self, "Dir")

        layout.prop(self, "Mode")

        layout.prop(self, "Fac")

        layout.prop(self, "Size")

        layout.prop_search(self, "ObjectName", bpy.data, "objects", icon="OBJECT_DATA")

        try:
            TestNode_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop(self, "Dir")

        layout.prop(self, "Mode")

        layout.prop(self, "Fac")

        layout.prop(self, "Size")

        layout.prop(self, "test")

        layout.prop_search(self, "ObjectName", bpy.data, "objects", icon="OBJECT_DATA")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            TestNode_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return TestNode_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "sUpdate" not in keys:
            sUpdate = self.inputs.new('NodeTreeBOOL', "sUpdate")

        keys = self.outputs.keys()
      
        if "timer" not in keys:
            timer=self.outputs.new('NodeTreeFLOAT', "timer")
        
# Derived from the Node base type.
class MessageSend(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''null'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'MessageSend'
    # Label for nice name display
    bl_label = 'MessageSend'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    TYPE = bpy.props.StringProperty(
        name="TYPE"
        ,default=""
        ,subtype="NONE"
        ,maxlen=0
        ,description="The NODE"
        
        )
    
    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "SEND",
"VALUE",
"EXT",

            ]        
    outputsockets=[
             
            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        SEND = self.inputs.new('NodeTreeBOOL', "SEND")

        VALUE = self.inputs.new('NodeTreeSTRING', "VALUE")

        EXT = self.inputs.new('NodeTreeSTRING', "EXT")

        try:
            MessageSend_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'MessageSend',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'MessageSend',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'MessageSend',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop(self, "TYPE")

        try:
            MessageSend_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop(self, "TYPE")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            MessageSend_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return MessageSend_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "SEND" not in keys:
            SEND = self.inputs.new('NodeTreeBOOL', "SEND")

        if "VALUE" not in keys:
            VALUE = self.inputs.new('NodeTreeSTRING', "VALUE")

        if "EXT" not in keys:
            EXT = self.inputs.new('NodeTreeSTRING', "EXT")

        keys = self.outputs.keys()

# Derived from the Node base type.
class MessageGet(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''null'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'MessageGet'
    # Label for nice name display
    bl_label = 'MessageGet'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    TYPE = bpy.props.StringProperty(
        name="TYPE"
        ,default="null"
        ,subtype="NONE"
        ,maxlen=0
        ,description="The NODE"
        
        )
    
    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             
            ]        
    outputsockets=[
             "FIRED",
"NOT_FIRED",
"VALUE",
"EXT",

            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        FIRED=self.outputs.new('NodeTreeBOOL', "FIRED")
        
        NOT_FIRED=self.outputs.new('NodeTreeBOOL', "NOT_FIRED")
        
        VALUE=self.outputs.new('NodeTreeSTRING', "VALUE")
        
        EXT=self.outputs.new('NodeTreeSTRING', "EXT")
        
        try:
            MessageGet_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'MessageGet',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'MessageGet',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'MessageGet',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop(self, "TYPE")

        try:
            MessageGet_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop(self, "TYPE")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            MessageGet_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return MessageGet_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
      
        keys = self.outputs.keys()
      
        if "FIRED" not in keys:
            FIRED=self.outputs.new('NodeTreeBOOL', "FIRED")
        
        if "NOT_FIRED" not in keys:
            NOT_FIRED=self.outputs.new('NodeTreeBOOL', "NOT_FIRED")
        
        if "VALUE" not in keys:
            VALUE=self.outputs.new('NodeTreeSTRING', "VALUE")
        
        if "EXT" not in keys:
            EXT=self.outputs.new('NodeTreeSTRING', "EXT")
        
# Derived from the Node base type.
class ObjectManipulator(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''manipulate object-data'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'ObjectManipulator'
    # Label for nice name display
    bl_label = 'ObjectManipulator'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    TYPE_items = [
        ("CREATE_INSTANCE", "CREATE INSTANCE", "CREATE INSTANCE"),
        ("DESTROY_INSTANCE", "DESTROY INSTANCE", "DESTROY INSTANCE"),

    ]
    TYPE = bpy.props.EnumProperty(description="null", items=TYPE_items, default="CREATE_INSTANCE")
    
    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "ENABLED",
"TARGET",

            ]        
    outputsockets=[
             
            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        ENABLED = self.inputs.new('NodeTreeBOOL', "ENABLED")

        TARGET = self.inputs.new('NodeTreeObject', "TARGET")

        try:
            ObjectManipulator_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'ObjectManipulator',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'ObjectManipulator',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'ObjectManipulator',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop(self, "TYPE")

        try:
            ObjectManipulator_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop(self, "TYPE")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            ObjectManipulator_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return ObjectManipulator_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "ENABLED" not in keys:
            ENABLED = self.inputs.new('NodeTreeBOOL', "ENABLED")

        if "TARGET" not in keys:
            TARGET = self.inputs.new('NodeTreeObject', "TARGET")

        keys = self.outputs.keys()

# Derived from the Node base type.
class CharacterNode(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''manipulate character'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'CharacterNode'
    # Label for nice name display
    bl_label = 'CharacterNode'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "obj",
"linvel",
"updateLinvel",
"gravity",
"rotAxis",
"rotVal",
"updateRot",
"jumpSpeed",
"fallSpeed",
"doJump",

            ]        
    outputsockets=[
             "isOnGround",

            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        obj = self.inputs.new('NodeTreeObject', "obj")

        linvel = self.inputs.new('NodeTreeVec3', "linvel")

        updateLinvel = self.inputs.new('NodeTreeBOOL', "updateLinvel")

        gravity = self.inputs.new('NodeTreeVec3', "gravity")

        rotAxis = self.inputs.new('NodeTreeVec3', "rotAxis")

        rotVal = self.inputs.new('NodeTreeFLOAT', "rotVal")

        updateRot = self.inputs.new('NodeTreeBOOL', "updateRot")

        jumpSpeed = self.inputs.new('NodeTreeFLOAT', "jumpSpeed")

        fallSpeed = self.inputs.new('NodeTreeFLOAT', "fallSpeed")

        doJump = self.inputs.new('NodeTreeBOOL', "doJump")

        isOnGround=self.outputs.new('NodeTreeBOOL', "isOnGround")
        
        try:
            CharacterNode_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'CharacterNode',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'CharacterNode',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'CharacterNode',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        try:
            CharacterNode_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            CharacterNode_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return CharacterNode_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "obj" not in keys:
            obj = self.inputs.new('NodeTreeObject', "obj")

        if "linvel" not in keys:
            linvel = self.inputs.new('NodeTreeVec3', "linvel")

        if "updateLinvel" not in keys:
            updateLinvel = self.inputs.new('NodeTreeBOOL', "updateLinvel")

        if "gravity" not in keys:
            gravity = self.inputs.new('NodeTreeVec3', "gravity")

        if "rotAxis" not in keys:
            rotAxis = self.inputs.new('NodeTreeVec3', "rotAxis")

        if "rotVal" not in keys:
            rotVal = self.inputs.new('NodeTreeFLOAT', "rotVal")

        if "updateRot" not in keys:
            updateRot = self.inputs.new('NodeTreeBOOL', "updateRot")

        if "jumpSpeed" not in keys:
            jumpSpeed = self.inputs.new('NodeTreeFLOAT', "jumpSpeed")

        if "fallSpeed" not in keys:
            fallSpeed = self.inputs.new('NodeTreeFLOAT', "fallSpeed")

        if "doJump" not in keys:
            doJump = self.inputs.new('NodeTreeBOOL', "doJump")

        keys = self.outputs.keys()
      
        if "isOnGround" not in keys:
            isOnGround=self.outputs.new('NodeTreeBOOL', "isOnGround")
        
# Derived from the Node base type.
class Sequence(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''null'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'Sequence'
    # Label for nice name display
    bl_label = 'Sequence'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "ENABLE",
"RESET",

            ]        
    outputsockets=[
             "FINISHED",
"LOGIC",
"ACTIVE",
"ON_START",
"ON_END",

            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        ENABLE = self.inputs.new('NodeTreeBOOL', "ENABLE")

        RESET = self.inputs.new('NodeTreeBOOL', "RESET")

        FINISHED=self.outputs.new('NodeTreeBOOL', "FINISHED")
        
        LOGIC=self.outputs.new('NodeTreeBOOL', "LOGIC")
        
        ACTIVE=self.outputs.new('NodeTreeBOOL', "ACTIVE")
        
        ON_START=self.outputs.new('NodeTreeBOOL', "ON_START")
        
        ON_END=self.outputs.new('NodeTreeBOOL', "ON_END")
        
        try:
            Sequence_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'Sequence',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'Sequence',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'Sequence',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        try:
            Sequence_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            Sequence_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return Sequence_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "ENABLE" not in keys:
            ENABLE = self.inputs.new('NodeTreeBOOL', "ENABLE")

        if "RESET" not in keys:
            RESET = self.inputs.new('NodeTreeBOOL', "RESET")

        keys = self.outputs.keys()
      
        if "FINISHED" not in keys:
            FINISHED=self.outputs.new('NodeTreeBOOL', "FINISHED")
        
        if "LOGIC" not in keys:
            LOGIC=self.outputs.new('NodeTreeBOOL', "LOGIC")
        
        if "ACTIVE" not in keys:
            ACTIVE=self.outputs.new('NodeTreeBOOL', "ACTIVE")
        
        if "ON_START" not in keys:
            ON_START=self.outputs.new('NodeTreeBOOL', "ON_START")
        
        if "ON_END" not in keys:
            ON_END=self.outputs.new('NodeTreeBOOL', "ON_END")
        
# Derived from the Node base type.
class SeqFinished(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''null'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'SeqFinished'
    # Label for nice name display
    bl_label = 'SeqFinished'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    TYPE_items = [
        ("ONCE", "ONCE", "Stays finished once set finished"),
        ("ALWAYS", "ALWAYS", "Changes mode as input changes"),

    ]
    TYPE = bpy.props.EnumProperty(description="null", items=TYPE_items, default="ONCE")
    
    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "connect",
"finished",

            ]        
    outputsockets=[
             
            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        connect = self.inputs.new('NodeTreeBOOL', "connect")

        finished = self.inputs.new('NodeTreeBOOL', "finished")

        try:
            SeqFinished_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'SeqFinished',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'SeqFinished',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'SeqFinished',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop(self, "TYPE")

        try:
            SeqFinished_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop(self, "TYPE")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            SeqFinished_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return SeqFinished_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "connect" not in keys:
            connect = self.inputs.new('NodeTreeBOOL', "connect")

        if "finished" not in keys:
            finished = self.inputs.new('NodeTreeBOOL', "finished")

        keys = self.outputs.keys()

# Derived from the Node base type.
class SeqTime(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''null'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'SeqTime'
    # Label for nice name display
    bl_label = 'SeqTime'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    WAIT = bpy.props.FloatProperty(
        name="WAIT"

        ,default=0.0
        
        ,subtype="NONE"

        ,unit="NONE"
        ,precision=2
     
        ,description="no desc"

        )
  
    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "connect",

            ]        
    outputsockets=[
             
            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        connect = self.inputs.new('NodeTreeBOOL', "connect")

        try:
            SeqTime_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'SeqTime',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'SeqTime',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'SeqTime',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop(self, "WAIT")

        try:
            SeqTime_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop(self, "WAIT")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            SeqTime_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return SeqTime_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "connect" not in keys:
            connect = self.inputs.new('NodeTreeBOOL', "connect")

        keys = self.outputs.keys()

# Derived from the Node base type.
class MotionNode(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''add motion to an object'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'MotionNode'
    # Label for nice name display
    bl_label = 'Motion Node'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    MaxVec = bpy.props.FloatVectorProperty(
        name="MaxVec"

        ,default=(10,10,10)
        
        ,subtype="NONE"

        ,unit="NONE"
        ,precision=0
     
        ,size=3
   
        ,description="no desc"

        )

    MinVec = bpy.props.FloatVectorProperty(
        name="MinVec"

        ,default=(-10,-10,-10)
        
        ,subtype="NONE"

        ,unit="NONE"
        ,precision=0
     
        ,size=3
   
        ,description="no desc"

        )

    KeepXYZ = bpy.props.BoolVectorProperty(
        name="KeepXYZ"
        
        ,subtype="NONE"
     
        ,size=3
   
        ,description="no desc"

        )
  
    Motion_items = [
        ("none", "none", "no motion at all"),
        ("rotation", "rotation", "rotation"),
        ("translation", "translation", "translation"),
        ("scale", "scale", "scale"),
        ("force", "force", "force"),
        ("torque", "torque", "torque"),
        ("linvel", "linear vel", "linear velocity"),
        ("angvel", "angular vel", "angular velocity"),
        ("set_rot", "set rotation", "absolute rotation"),
        ("set_pos", "set position", "set position"),

    ]
    Motion = bpy.props.EnumProperty(description="null", items=Motion_items, default="none")
  
    Space_items = [
        ("local", "local", "Local Space"),
        ("parent", "parent", "Parent Space"),
        ("world", "world", "World Space"),

    ]
    Space = bpy.props.EnumProperty(description="null", items=Space_items, default="local")
    
    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "OBJECT",
"UPDATE",
"X",
"Y",
"Z",
"DAMPING",

            ]        
    outputsockets=[
             "RESULT",

            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        OBJECT = self.inputs.new('NodeTreeSTRING', "OBJECT")

        UPDATE = self.inputs.new('NodeTreeBOOL', "UPDATE")

        X = self.inputs.new('NodeTreeFLOAT', "X")

        Y = self.inputs.new('NodeTreeFLOAT', "Y")

        Z = self.inputs.new('NodeTreeFLOAT', "Z")

        DAMPING = self.inputs.new('NodeTreeFLOAT', "DAMPING")

        RESULT=self.outputs.new('NodeTreeFLOAT', "RESULT")
        
        try:
            MotionNode_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'MotionNode',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'MotionNode',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'MotionNode',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop(self, "Motion")

        layout.prop(self, "Space")

        layout.prop(self, "MaxVec")

        layout.prop(self, "MinVec")

        layout.prop(self, "KeepXYZ")

        try:
            MotionNode_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop(self, "Motion")

        layout.prop(self, "Space")

        layout.prop(self, "MaxVec")

        layout.prop(self, "MinVec")

        layout.prop(self, "KeepXYZ")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            MotionNode_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return MotionNode_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "OBJECT" not in keys:
            OBJECT = self.inputs.new('NodeTreeSTRING', "OBJECT")

        if "UPDATE" not in keys:
            UPDATE = self.inputs.new('NodeTreeBOOL', "UPDATE")

        if "X" not in keys:
            X = self.inputs.new('NodeTreeFLOAT', "X")

        if "Y" not in keys:
            Y = self.inputs.new('NodeTreeFLOAT', "Y")

        if "Z" not in keys:
            Z = self.inputs.new('NodeTreeFLOAT', "Z")

        if "DAMPING" not in keys:
            DAMPING = self.inputs.new('NodeTreeFLOAT', "DAMPING")

        keys = self.outputs.keys()
      
        if "RESULT" not in keys:
            RESULT=self.outputs.new('NodeTreeFLOAT', "RESULT")
        
# Derived from the Node base type.
class MouseNode(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''Mouse checks'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'MouseNode'
    # Label for nice name display
    bl_label = 'Mouse Node'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "SCALE_X",
"SCALE_Y",

            ]        
    outputsockets=[
             "MOTION",
"REL_X",
"REL_Y",
"ABS_X",
"ABS_Y",
"WHEEL",
"WHEEL_MOTION",

            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        SCALE_X = self.inputs.new('NodeTreeFLOAT', "SCALE_X")
        
        SCALE_X.value = 1.0

        SCALE_Y = self.inputs.new('NodeTreeFLOAT', "SCALE_Y")
        
        SCALE_Y.value = 1.0

        MOTION=self.outputs.new('NodeTreeBOOL', "MOTION")
        
        REL_X=self.outputs.new('NodeTreeFLOAT', "REL_X")
        
        REL_Y=self.outputs.new('NodeTreeFLOAT', "REL_Y")
        
        ABS_X=self.outputs.new('NodeTreeFLOAT', "ABS_X")
        
        ABS_Y=self.outputs.new('NodeTreeFLOAT', "ABS_Y")
        
        WHEEL=self.outputs.new('NodeTreeFLOAT', "WHEEL")
        
        WHEEL_MOTION=self.outputs.new('NodeTreeBOOL', "WHEEL_MOTION")
        
        try:
            MouseNode_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'MouseNode',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'MouseNode',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'MouseNode',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        try:
            MouseNode_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            MouseNode_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return MouseNode_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "SCALE_X" not in keys:
            SCALE_X = self.inputs.new('NodeTreeFLOAT', "SCALE_X")

        if "SCALE_Y" not in keys:
            SCALE_Y = self.inputs.new('NodeTreeFLOAT', "SCALE_Y")

        keys = self.outputs.keys()
      
        if "MOTION" not in keys:
            MOTION=self.outputs.new('NodeTreeBOOL', "MOTION")
        
        if "REL_X" not in keys:
            REL_X=self.outputs.new('NodeTreeFLOAT', "REL_X")
        
        if "REL_Y" not in keys:
            REL_Y=self.outputs.new('NodeTreeFLOAT', "REL_Y")
        
        if "ABS_X" not in keys:
            ABS_X=self.outputs.new('NodeTreeFLOAT', "ABS_X")
        
        if "ABS_Y" not in keys:
            ABS_Y=self.outputs.new('NodeTreeFLOAT', "ABS_Y")
        
        if "WHEEL" not in keys:
            WHEEL=self.outputs.new('NodeTreeFLOAT', "WHEEL")
        
        if "WHEEL_MOTION" not in keys:
            WHEEL_MOTION=self.outputs.new('NodeTreeBOOL', "WHEEL_MOTION")
        
# Derived from the Node base type.
class BoolNode(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''null'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'BoolNode'
    # Label for nice name display
    bl_label = 'Bool Node'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    Operation_items = [
        ("and", "and", "and"),
        ("or", "or", "or"),
        ("not", "not", "not A"),
        ("if", "if", "is A true?"),

    ]
    Operation = bpy.props.EnumProperty(description="null", items=Operation_items, default="and")
    
    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "A",
"B",

            ]        
    outputsockets=[
             "RESULT",
"NOT",

            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        A = self.inputs.new('NodeTreeBOOL', "A")

        B = self.inputs.new('NodeTreeBOOL', "B")

        RESULT=self.outputs.new('NodeTreeBOOL', "RESULT")
        
        NOT=self.outputs.new('NodeTreeBOOL', "NOT")
        
        try:
            BoolNode_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'BoolNode',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'BoolNode',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'BoolNode',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop(self, "Operation")

        try:
            BoolNode_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop(self, "Operation")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            BoolNode_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return BoolNode_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "A" not in keys:
            A = self.inputs.new('NodeTreeBOOL', "A")

        if "B" not in keys:
            B = self.inputs.new('NodeTreeBOOL', "B")

        keys = self.outputs.keys()
      
        if "RESULT" not in keys:
            RESULT=self.outputs.new('NodeTreeBOOL', "RESULT")
        
        if "NOT" not in keys:
            NOT=self.outputs.new('NodeTreeBOOL', "NOT")
        
# Derived from the Node base type.
class MathNode(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''All Kind of Math-Magic'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'MathNode'
    # Label for nice name display
    bl_label = 'Math Node'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    Operation_items = [
        ("no_func", "no_func", "Do nothing"),
        ("add", "add", "Add two values"),
        ("sub", "sub", "sub two"),
        ("mul", "mul", "mul two"),
        ("div", "div", "div two"),
        ("sin", "sin", "sin"),
        ("cos", "cos", "cos"),
        ("tan", "tan", "tan"),
        ("asin", "asin", "asin"),
        ("acos", "acos", "acos"),
        ("atan", "atan", "atan"),
        ("power", "power", "power"),
        ("log", "log", "log"),
        ("min", "min", "min"),
        ("max", "max", "max"),
        ("round", "round", "round"),
        ("lt", "lt", "lt"),
        ("gt", "gt", "gt"),
        ("sqrt", "sqrt", "sqrt"),
        ("sqr", "sqr", "sqr"),
        ("inv", "inv", "Inverse"),

    ]
    Operation = bpy.props.EnumProperty(description="null", items=Operation_items, default="no_func")
    
    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "A",
"B",

            ]        
    outputsockets=[
             "RESULT",

            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        A = self.inputs.new('NodeTreeFLOAT', "A")

        B = self.inputs.new('NodeTreeFLOAT', "B")

        RESULT=self.outputs.new('NodeTreeFLOAT', "RESULT")
        
        try:
            MathNode_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'MathNode',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'MathNode',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'MathNode',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop(self, "Operation")

        try:
            MathNode_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop(self, "Operation")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            MathNode_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return MathNode_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "A" not in keys:
            A = self.inputs.new('NodeTreeFLOAT', "A")

        if "B" not in keys:
            B = self.inputs.new('NodeTreeFLOAT', "B")

        keys = self.outputs.keys()
      
        if "RESULT" not in keys:
            RESULT=self.outputs.new('NodeTreeFLOAT', "RESULT")
        
# Derived from the Node base type.
class TimerNode(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''null'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'TimerNode'
    # Label for nice name display
    bl_label = 'Timer'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    ORDER_items = [
        ("asc", "asc", "asc"),
        ("desc", "desc", "desc"),

    ]
    ORDER = bpy.props.EnumProperty(description="null", items=ORDER_items, default="asc")
    
    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "initTime",
"UPDATE",
"RESET",

            ]        
    outputsockets=[
             "CURRENT_TIME",
"IS_DONE",
"IS_RUNNING",

            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        initTime = self.inputs.new('NodeTreeFLOAT', "initTime")

        UPDATE = self.inputs.new('NodeTreeBOOL', "UPDATE")

        RESET = self.inputs.new('NodeTreeBOOL', "RESET")

        CURRENT_TIME=self.outputs.new('NodeTreeFLOAT', "CURRENT_TIME")
        
        IS_DONE=self.outputs.new('NodeTreeBOOL', "IS_DONE")
        
        IS_RUNNING=self.outputs.new('NodeTreeBOOL', "IS_RUNNING")
        
        try:
            TimerNode_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'TimerNode',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'TimerNode',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'TimerNode',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop(self, "ORDER")

        try:
            TimerNode_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop(self, "ORDER")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            TimerNode_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return TimerNode_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "initTime" not in keys:
            initTime = self.inputs.new('NodeTreeFLOAT', "initTime")

        if "UPDATE" not in keys:
            UPDATE = self.inputs.new('NodeTreeBOOL', "UPDATE")

        if "RESET" not in keys:
            RESET = self.inputs.new('NodeTreeBOOL', "RESET")

        keys = self.outputs.keys()
      
        if "CURRENT_TIME" not in keys:
            CURRENT_TIME=self.outputs.new('NodeTreeFLOAT', "CURRENT_TIME")
        
        if "IS_DONE" not in keys:
            IS_DONE=self.outputs.new('NodeTreeBOOL', "IS_DONE")
        
        if "IS_RUNNING" not in keys:
            IS_RUNNING=self.outputs.new('NodeTreeBOOL', "IS_RUNNING")
        
# Derived from the Node base type.
class ObjectNode(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''Select any Object'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'ObjectNode'
    # Label for nice name display
    bl_label = 'Object Node'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    Obj = bpy.props.StringProperty(
        name="Obj"
        ,default="null"
        ,subtype="NONE"
        ,maxlen=0
        ,description="The NODE"
        
        )
    
    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    GLOBAL = bpy.props.BoolProperty(
        name="GLOBAL"
        
        ,subtype="NONE"
     
        ,description="Use this object if global. If false group-instances first try to locate an object with this name in the group!"

        )
  
    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             
            ]        
    outputsockets=[
             "OBJECT",

            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        OBJECT=self.outputs.new('NodeTreeSTRING', "OBJECT")
        
        try:
            ObjectNode_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'ObjectNode',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'ObjectNode',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'ObjectNode',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop(self, "GLOBAL")

        layout.prop_search(self, "Obj", bpy.data, "objects", icon="OBJECT_DATA")

        try:
            ObjectNode_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop(self, "GLOBAL")

        layout.prop_search(self, "Obj", bpy.data, "objects", icon="OBJECT_DATA")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            ObjectNode_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return ObjectNode_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
      
        keys = self.outputs.keys()
      
        if "OBJECT" not in keys:
            OBJECT=self.outputs.new('NodeTreeSTRING', "OBJECT")
        
# Derived from the Node base type.
class ObjectData(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''Access object data'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'ObjectData'
    # Label for nice name display
    bl_label = 'ObjectData'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "OBJECT",

            ]        
    outputsockets=[
             "WPOS",
"POS",
"WROT",
"ROT",
"WSCALE",
"SCALE",
"LINVEL",
"ANGVEL",

            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        OBJECT = self.inputs.new('NodeTreeObject', "OBJECT")

        WPOS=self.outputs.new('NodeTreeVec3', "WPOS")
        
        POS=self.outputs.new('NodeTreeVec3', "POS")
        
        WROT=self.outputs.new('NodeTreeVec3', "WROT")
        
        ROT=self.outputs.new('NodeTreeVec3', "ROT")
        
        WSCALE=self.outputs.new('NodeTreeVec3', "WSCALE")
        
        SCALE=self.outputs.new('NodeTreeVec3', "SCALE")
        
        LINVEL=self.outputs.new('NodeTreeVec3', "LINVEL")
        
        ANGVEL=self.outputs.new('NodeTreeVec3', "ANGVEL")
        
        try:
            ObjectData_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'ObjectData',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'ObjectData',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'ObjectData',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        try:
            ObjectData_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            ObjectData_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return ObjectData_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "OBJECT" not in keys:
            OBJECT = self.inputs.new('NodeTreeObject', "OBJECT")

        keys = self.outputs.keys()
      
        if "WPOS" not in keys:
            WPOS=self.outputs.new('NodeTreeVec3', "WPOS")
        
        if "POS" not in keys:
            POS=self.outputs.new('NodeTreeVec3', "POS")
        
        if "WROT" not in keys:
            WROT=self.outputs.new('NodeTreeVec3', "WROT")
        
        if "ROT" not in keys:
            ROT=self.outputs.new('NodeTreeVec3', "ROT")
        
        if "WSCALE" not in keys:
            WSCALE=self.outputs.new('NodeTreeVec3', "WSCALE")
        
        if "SCALE" not in keys:
            SCALE=self.outputs.new('NodeTreeVec3', "SCALE")
        
        if "LINVEL" not in keys:
            LINVEL=self.outputs.new('NodeTreeVec3', "LINVEL")
        
        if "ANGVEL" not in keys:
            ANGVEL=self.outputs.new('NodeTreeVec3', "ANGVEL")
        
# Derived from the Node base type.
class Accelerometer(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''null'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'Accelerometer'
    # Label for nice name display
    bl_label = 'Accelerometer'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "UPDATE",

            ]        
    outputsockets=[
             "X",
"Y",
"Z",

            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        UPDATE = self.inputs.new('NodeTreeBOOL', "UPDATE")

        X=self.outputs.new('NodeTreeFLOAT', "X")
        
        Y=self.outputs.new('NodeTreeFLOAT', "Y")
        
        Z=self.outputs.new('NodeTreeFLOAT', "Z")
        
        try:
            Accelerometer_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'Accelerometer',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'Accelerometer',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'Accelerometer',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        try:
            Accelerometer_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            Accelerometer_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return Accelerometer_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "UPDATE" not in keys:
            UPDATE = self.inputs.new('NodeTreeBOOL', "UPDATE")

        keys = self.outputs.keys()
      
        if "X" not in keys:
            X=self.outputs.new('NodeTreeFLOAT', "X")
        
        if "Y" not in keys:
            Y=self.outputs.new('NodeTreeFLOAT', "Y")
        
        if "Z" not in keys:
            Z=self.outputs.new('NodeTreeFLOAT', "Z")
        
# Derived from the Node base type.
class VectorDecomp(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''null'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'VectorDecomp'
    # Label for nice name display
    bl_label = 'VectorDecomp'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "vec",

            ]        
    outputsockets=[
             "x",
"y",
"z",

            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        vec = self.inputs.new('NodeTreeVec3', "vec")

        x=self.outputs.new('NodeTreeFLOAT', "x")
        
        y=self.outputs.new('NodeTreeFLOAT', "y")
        
        z=self.outputs.new('NodeTreeFLOAT', "z")
        
        try:
            VectorDecomp_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'VectorDecomp',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'VectorDecomp',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'VectorDecomp',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        try:
            VectorDecomp_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            VectorDecomp_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return VectorDecomp_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "vec" not in keys:
            vec = self.inputs.new('NodeTreeVec3', "vec")

        keys = self.outputs.keys()
      
        if "x" not in keys:
            x=self.outputs.new('NodeTreeFLOAT', "x")
        
        if "y" not in keys:
            y=self.outputs.new('NodeTreeFLOAT', "y")
        
        if "z" not in keys:
            z=self.outputs.new('NodeTreeFLOAT', "z")
        
# Derived from the Node base type.
class NodeTreeNode(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''Select NodeTrees'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'NodeTreeNode'
    # Label for nice name display
    bl_label = 'NodeTree Node'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    nodetree = bpy.props.StringProperty(
        name="nodetree"
        ,default=""
        ,subtype="NONE"
        ,maxlen=0
        ,description="The NODE"
        
        )
    
    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "ENABLED",
"TARGET_OBJ",

            ]        
    outputsockets=[
             "nodetree",

            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        ENABLED = self.inputs.new('NodeTreeBOOL', "ENABLED")

        TARGET_OBJ = self.inputs.new('NodeTreeSTRING', "TARGET_OBJ")

        nodetree=self.outputs.new('NodeTreeSTRING', "nodetree")
        
        try:
            NodeTreeNode_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'NodeTreeNode',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'NodeTreeNode',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'NodeTreeNode',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop_search(self, "nodetree", bpy.data, "node_groups", icon="NODETREE")

        try:
            NodeTreeNode_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop_search(self, "nodetree", bpy.data, "node_groups", icon="NODETREE")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            NodeTreeNode_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return NodeTreeNode_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "ENABLED" not in keys:
            ENABLED = self.inputs.new('NodeTreeBOOL', "ENABLED")

        if "TARGET_OBJ" not in keys:
            TARGET_OBJ = self.inputs.new('NodeTreeSTRING', "TARGET_OBJ")

        keys = self.outputs.keys()
      
        if "nodetree" not in keys:
            nodetree=self.outputs.new('NodeTreeSTRING', "nodetree")
        
# Derived from the Node base type.
class StateMachine(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''null'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'StateMachine'
    # Label for nice name display
    bl_label = 'StateMachine'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    #wrapper to the implemented update-call, to ensure no exception will be thrown
    def StateMachine_GLOBAL_updateCaller(self,context):
        try:
            print("Check for logic:"+str(type(self)))
            logic = runtimedata.RuntimeData.runtime.getLogic(self.bpid)
            if logic:
                try: # first check if there is a corresponding method in the logic 
                    logic.update_GLOBAL(self,context) 
                    return
                except:
                    print (traceback.format_exc())
                    pass
            else:
                print("NO LOGIC")
            # now try it the old way
            StateMachine_GLOBAL_update(self,context)
        except:
            print(traceback.format_exc())
            
    #wrapper to the implemented update-call, to ensure no exception will be thrown
    def StateMachine_NAME_updateCaller(self,context):
        try:
            print("Check for logic:"+str(type(self)))
            logic = runtimedata.RuntimeData.runtime.getLogic(self.bpid)
            if logic:
                try: # first check if there is a corresponding method in the logic 
                    logic.update_NAME(self,context) 
                    return
                except:
                    print (traceback.format_exc())
                    pass
            else:
                print("NO LOGIC")
            # now try it the old way
            StateMachine_NAME_update(self,context)
        except:
            print(traceback.format_exc())
            
    NAME = bpy.props.StringProperty(
        name="NAME"
        ,default=""
        ,subtype="NONE"
        ,maxlen=0
        ,description="The NODE"

        ,update=StateMachine_NAME_updateCaller
        
        )
    
    INITIAL_STATE = bpy.props.StringProperty(
        name="INITIAL_STATE"
        ,default=""
        ,subtype="NONE"
        ,maxlen=0
        ,description="The NODE"
        
        )
    
    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    GLOBAL = bpy.props.BoolProperty(
        name="GLOBAL"

        ,default=0
        
        ,subtype="NONE"
     
        ,description="no desc"

        ,update=StateMachine_GLOBAL_updateCaller
       
        )
  
    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "UPDATE",

            ]        
    outputsockets=[
             "STATES",
"CURRENT_STATE",

            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 100
        
        UPDATE = self.inputs.new('NodeTreeBOOL', "UPDATE")

        STATES=self.outputs.new('NodeTreeSTRING', "STATES")
        
        CURRENT_STATE=self.outputs.new('NodeTreeINT', "CURRENT_STATE")
        
        try:
            StateMachine_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'StateMachine',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'StateMachine',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'StateMachine',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop(self, "GLOBAL")

        layout.prop(self, "NAME")

        try:
            StateMachine_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop(self, "GLOBAL")

        layout.prop(self, "NAME")

        layout.prop(self, "INITIAL_STATE")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            StateMachine_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return StateMachine_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "UPDATE" not in keys:
            UPDATE = self.inputs.new('NodeTreeBOOL', "UPDATE")

        keys = self.outputs.keys()
      
        if "STATES" not in keys:
            STATES=self.outputs.new('NodeTreeSTRING', "STATES")
        
        if "CURRENT_STATE" not in keys:
            CURRENT_STATE=self.outputs.new('NodeTreeINT', "CURRENT_STATE")
        
# Derived from the Node base type.
class State(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''null'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'State'
    # Label for nice name display
    bl_label = 'State'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    #wrapper to the implemented update-call, to ensure no exception will be thrown
    def State_NAME_updateCaller(self,context):
        try:
            print("Check for logic:"+str(type(self)))
            logic = runtimedata.RuntimeData.runtime.getLogic(self.bpid)
            if logic:
                try: # first check if there is a corresponding method in the logic 
                    logic.update_NAME(self,context) 
                    return
                except:
                    print (traceback.format_exc())
                    pass
            else:
                print("NO LOGIC")
            # now try it the old way
            State_NAME_update(self,context)
        except:
            print(traceback.format_exc())
            
    NAME = bpy.props.StringProperty(
        name="NAME"
        ,default=""
        ,subtype="NONE"
        ,maxlen=0
        ,description="The NODE"

        ,update=State_NAME_updateCaller
        
        )
    
    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    ID = bpy.props.IntProperty(
        name="ID"

        ,default=0
        
        ,subtype="NONE"
     
        ,description="no desc"

        )
  
    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "STATE_ID",

            ]        
    outputsockets=[
             "START_TRIGGER",
"ACTIVE",
"END_TRIGGER",

            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        STATE_ID = self.inputs.new('NodeTreeBOOL', "STATE_ID")

        START_TRIGGER=self.outputs.new('NodeTreeBOOL', "START_TRIGGER")
        
        ACTIVE=self.outputs.new('NodeTreeBOOL', "ACTIVE")
        
        END_TRIGGER=self.outputs.new('NodeTreeBOOL', "END_TRIGGER")
        
        try:
            State_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'State',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'State',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'State',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop(self, "NAME")

        layout.prop(self, "ID")

        try:
            State_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop(self, "NAME")

        layout.prop(self, "ID")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            State_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return State_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "STATE_ID" not in keys:
            STATE_ID = self.inputs.new('NodeTreeBOOL', "STATE_ID")

        keys = self.outputs.keys()
      
        if "START_TRIGGER" not in keys:
            START_TRIGGER=self.outputs.new('NodeTreeBOOL', "START_TRIGGER")
        
        if "ACTIVE" not in keys:
            ACTIVE=self.outputs.new('NodeTreeBOOL', "ACTIVE")
        
        if "END_TRIGGER" not in keys:
            END_TRIGGER=self.outputs.new('NodeTreeBOOL', "END_TRIGGER")
        
# Derived from the Node base type.
class StateTransition(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''Switch from one state to another'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'StateTransition'
    # Label for nice name display
    bl_label = 'StateTransition'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    WAIT = bpy.props.IntProperty(
        name="WAIT"

        ,default=0
        
        ,subtype="NONE"
     
        ,description="no desc"

        )
  
    COND_TYPE_items = [
        ("lua", "lua", "Lua Condition: a lua function that will check the condition. Return true to execute transition!"),

    ]
    COND_TYPE = bpy.props.EnumProperty(description="null", items=COND_TYPE_items, default="lua")
    
    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "FROM",
"CONDITION",

            ]        
    outputsockets=[
             "TO",

            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        self.use_custom_color=True
        self.color=(0.098,0.612,0.098)
        
        FROM = self.inputs.new('NodeTreeBOOL', "FROM")

        CONDITION = self.inputs.new('NodeTreeBOOL', "CONDITION")
        
        CONDITION.value = 0

        TO=self.outputs.new('NodeTreeBOOL', "TO")
        
        try:
            StateTransition_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'StateTransition',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'StateTransition',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'StateTransition',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop(self, "COND_TYPE")

        layout.prop(self, "WAIT")

        try:
            StateTransition_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop(self, "COND_TYPE")

        layout.prop(self, "WAIT")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            StateTransition_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return StateTransition_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "FROM" not in keys:
            FROM = self.inputs.new('NodeTreeBOOL', "FROM")

        if "CONDITION" not in keys:
            CONDITION = self.inputs.new('NodeTreeBOOL', "CONDITION")

        keys = self.outputs.keys()
      
        if "TO" not in keys:
            TO=self.outputs.new('NodeTreeBOOL', "TO")
        
# Derived from the Node base type.
class StateMachineRef(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''null'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'StateMachineRef'
    # Label for nice name display
    bl_label = 'StateMachineRef'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    STM = bpy.props.StringProperty(
        name="STM"
        ,default=""
        ,subtype="NONE"
        ,maxlen=0
        ,description="The NODE"
        
        )
    
    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             
            ]        
    outputsockets=[
             "STM",
"CURRENT_STATE",

            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        STM=self.outputs.new('NodeTreeINT', "STM")
        
        CURRENT_STATE=self.outputs.new('NodeTreeINT', "CURRENT_STATE")
        
        try:
            StateMachineRef_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'StateMachineRef',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'StateMachineRef',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'StateMachineRef',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop(self, "STM")

        try:
            StateMachineRef_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop(self, "STM")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            StateMachineRef_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return StateMachineRef_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
      
        keys = self.outputs.keys()
      
        if "STM" not in keys:
            STM=self.outputs.new('NodeTreeINT', "STM")
        
        if "CURRENT_STATE" not in keys:
            CURRENT_STATE=self.outputs.new('NodeTreeINT', "CURRENT_STATE")
        
# Derived from the Node base type.
class StateRef(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''null'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'StateRef'
    # Label for nice name display
    bl_label = 'StateRef'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    #wrapper to the implemented update-call, to ensure no exception will be thrown
    def StateRef_GLOBAL_updateCaller(self,context):
        try:
            print("Check for logic:"+str(type(self)))
            logic = runtimedata.RuntimeData.runtime.getLogic(self.bpid)
            if logic:
                try: # first check if there is a corresponding method in the logic 
                    logic.update_GLOBAL(self,context) 
                    return
                except:
                    print (traceback.format_exc())
                    pass
            else:
                print("NO LOGIC")
            # now try it the old way
            StateRef_GLOBAL_update(self,context)
        except:
            print(traceback.format_exc())
            
    STM = bpy.props.StringProperty(
        name="STM"
        ,default=""
        ,subtype="NONE"
        ,maxlen=0
        ,description="The NODE"
        
        )
    
    STATE = bpy.props.StringProperty(
        name="STATE"
        ,default=""
        ,subtype="NONE"
        ,maxlen=0
        ,description="The NODE"
        
        )
    
    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    GLOBAL = bpy.props.BoolProperty(
        name="GLOBAL"

        ,default=0
        
        ,subtype="NONE"
     
        ,description="no desc"

        ,update=StateRef_GLOBAL_updateCaller
       
        )
  
    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "STATE",

            ]        
    outputsockets=[
             "ACTIVE",
"STATE",
"START_TRIGGER",
"END_TRIGGER",

            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        STATE = self.inputs.new('NodeTreeBOOL', "STATE")

        ACTIVE=self.outputs.new('NodeTreeBOOL', "ACTIVE")

        ACTIVE.value=0
        
        STATE=self.outputs.new('NodeTreeBOOL', "STATE")
        
        START_TRIGGER=self.outputs.new('NodeTreeBOOL', "START_TRIGGER")
        
        END_TRIGGER=self.outputs.new('NodeTreeBOOL', "END_TRIGGER")
        
        try:
            StateRef_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'StateRef',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'StateRef',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'StateRef',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop(self, "GLOBAL")

        try:
            StateRef_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop(self, "GLOBAL")

        layout.prop(self, "STM")

        layout.prop(self, "STATE")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            StateRef_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return StateRef_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "STATE" not in keys:
            STATE = self.inputs.new('NodeTreeBOOL', "STATE")

        keys = self.outputs.keys()
      
        if "ACTIVE" not in keys:
            ACTIVE=self.outputs.new('NodeTreeBOOL', "ACTIVE")
        
        if "STATE" not in keys:
            STATE=self.outputs.new('NodeTreeBOOL', "STATE")
        
        if "START_TRIGGER" not in keys:
            START_TRIGGER=self.outputs.new('NodeTreeBOOL', "START_TRIGGER")
        
        if "END_TRIGGER" not in keys:
            END_TRIGGER=self.outputs.new('NodeTreeBOOL', "END_TRIGGER")
        
# Derived from the Node base type.
class StateManipulator(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''null'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'StateManipulator'
    # Label for nice name display
    bl_label = 'StateManipulator'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    TYPE_items = [
        ("setstate", "set state", "Set the state"),

    ]
    TYPE = bpy.props.EnumProperty(description="null", items=TYPE_items, default="setstate")
    
    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "UPDATE",

            ]        
    outputsockets=[
             "MANIP_STATE",

            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        UPDATE = self.inputs.new('NodeTreeBOOL', "UPDATE")

        MANIP_STATE=self.outputs.new('NodeTreeSTRING', "MANIP_STATE")
        
        try:
            StateManipulator_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'StateManipulator',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'StateManipulator',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'StateManipulator',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop(self, "TYPE")

        try:
            StateManipulator_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop(self, "TYPE")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            StateManipulator_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return StateManipulator_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "UPDATE" not in keys:
            UPDATE = self.inputs.new('NodeTreeBOOL', "UPDATE")

        keys = self.outputs.keys()
      
        if "MANIP_STATE" not in keys:
            MANIP_STATE=self.outputs.new('NodeTreeSTRING', "MANIP_STATE")
        
# Derived from the Node base type.
class Property(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''with override you can set the propname via socket'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'Property'
    # Label for nice name display
    bl_label = 'Property'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    #wrapper to the implemented update-call, to ensure no exception will be thrown
    def Property_NAME_updateCaller(self,context):
        try:
            print("Check for logic:"+str(type(self)))
            logic = runtimedata.RuntimeData.runtime.getLogic(self.bpid)
            if logic:
                try: # first check if there is a corresponding method in the logic 
                    logic.update_NAME(self,context) 
                    return
                except:
                    print (traceback.format_exc())
                    pass
            else:
                print("NO LOGIC")
            # now try it the old way
            Property_NAME_update(self,context)
        except:
            print(traceback.format_exc())
            
    NAME = bpy.props.StringProperty(
        name="NAME"
        ,default=""
        ,subtype="NONE"
        ,maxlen=0
        ,description="The NODE"

        ,update=Property_NAME_updateCaller
        
        )
    
    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    MODE_items = [
        ("init_property", "init_property", "init23_property"),
        ("set_property", "set_property", "set_property"),
        ("remove_property", "remove_property", "remove_property"),

    ]
    MODE = bpy.props.EnumProperty(description="null", items=MODE_items, default="init_property")
  
    TYPE_items = [
        ("bool", "bool", "bool"),
        ("float", "float", "float"),
        ("string", "string", "string"),

    ]
    TYPE = bpy.props.EnumProperty(description="null", items=TYPE_items, default="bool")
    
    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "ENABLED",
"VALUE",
"TARGET_OBJ",
"OVERRIDE_NAME",

            ]        
    outputsockets=[
             "VALUE",

            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        ENABLED = self.inputs.new('NodeTreeBOOL', "ENABLED")

        VALUE = self.inputs.new('NodeTreeSTRING', "VALUE")

        TARGET_OBJ = self.inputs.new('NodeTreeSTRING', "TARGET_OBJ")

        OVERRIDE_NAME = self.inputs.new('NodeTreeSTRING', "OVERRIDE_NAME")

        VALUE=self.outputs.new('NodeTreeSTRING', "VALUE")
        
        try:
            Property_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'Property',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'Property',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'Property',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop(self, "MODE")

        layout.prop(self, "NAME")

        layout.prop(self, "TYPE")

        try:
            Property_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop(self, "MODE")

        layout.prop(self, "NAME")

        layout.prop(self, "TYPE")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            Property_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return Property_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "ENABLED" not in keys:
            ENABLED = self.inputs.new('NodeTreeBOOL', "ENABLED")

        if "VALUE" not in keys:
            VALUE = self.inputs.new('NodeTreeSTRING', "VALUE")

        if "TARGET_OBJ" not in keys:
            TARGET_OBJ = self.inputs.new('NodeTreeSTRING', "TARGET_OBJ")

        if "OVERRIDE_NAME" not in keys:
            OVERRIDE_NAME = self.inputs.new('NodeTreeSTRING', "OVERRIDE_NAME")

        keys = self.outputs.keys()
      
        if "VALUE" not in keys:
            VALUE=self.outputs.new('NodeTreeSTRING', "VALUE")
        
# Derived from the Node base type.
class PropertyGet(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''null'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'PropertyGet'
    # Label for nice name display
    bl_label = 'PropertyGet'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    NAME = bpy.props.StringProperty(
        name="NAME"
        ,default=""
        ,subtype="NONE"
        ,maxlen=0
        ,description="The NODE"
        
        )
    
    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    MANUAL = bpy.props.BoolProperty(
        name="MANUAL"
        
        ,subtype="NONE"
     
        ,description="no desc"

        )
  
    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "TARGET_OBJ",

            ]        
    outputsockets=[
             "VALUE",

            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        TARGET_OBJ = self.inputs.new('NodeTreeObject', "TARGET_OBJ")

        VALUE=self.outputs.new('NodeTreeSTRING', "VALUE")
        
        try:
            PropertyGet_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'PropertyGet',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'PropertyGet',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'PropertyGet',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop(self, "MANUAL")

        try:
            PropertyGet_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop(self, "MANUAL")

        layout.prop(self, "NAME")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            PropertyGet_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return PropertyGet_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "TARGET_OBJ" not in keys:
            TARGET_OBJ = self.inputs.new('NodeTreeObject', "TARGET_OBJ")

        keys = self.outputs.keys()
      
        if "VALUE" not in keys:
            VALUE=self.outputs.new('NodeTreeSTRING', "VALUE")
        
# Derived from the Node base type.
class NoOp(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''null'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'NoOp'
    # Label for nice name display
    bl_label = 'NoOp'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             
            ]        
    outputsockets=[
             
            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        try:
            NoOp_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'NoOp',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'NoOp',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'NoOp',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        try:
            NoOp_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            NoOp_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return NoOp_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
      
        keys = self.outputs.keys()

# Derived from the Node base type.
class TemplaterNode(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''null'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'TemplaterNode'
    # Label for nice name display
    bl_label = 'TemplaterNode'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    DOCNAME = bpy.props.StringProperty(
        name="DOCNAME"
        ,default=""
        ,subtype="NONE"
        ,maxlen=0
        ,description="The NODE"
        
        )
    
    TEMPLATE = bpy.props.StringProperty(
        name="TEMPLATE"
        ,default=""
        ,subtype="FILE_PATH"
        ,maxlen=0
        ,description="The NODE"
        
        )
    
    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             
            ]        
    outputsockets=[
             "FONTS",
"SCREENS",

            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        FONTS=self.outputs.new('NodeTreeBOOL', "FONTS")
        
        SCREENS=self.outputs.new('NodeTreeBOOL', "SCREENS")
        
        try:
            TemplaterNode_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'TemplaterNode',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'TemplaterNode',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'TemplaterNode',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop(self, "DOCNAME")

        layout.prop(self, "TEMPLATE")

        try:
            TemplaterNode_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop(self, "DOCNAME")

        layout.prop(self, "TEMPLATE")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            TemplaterNode_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return TemplaterNode_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
      
        keys = self.outputs.keys()
      
        if "FONTS" not in keys:
            FONTS=self.outputs.new('NodeTreeBOOL', "FONTS")
        
        if "SCREENS" not in keys:
            SCREENS=self.outputs.new('NodeTreeBOOL', "SCREENS")
        
# Derived from the Node base type.
class ScreenAction(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''null'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'ScreenAction'
    # Label for nice name display
    bl_label = 'ScreenAction'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    DOC = bpy.props.StringProperty(
        name="DOC"
        ,default=""
        ,subtype="NONE"
        ,maxlen=0
        ,description="The NODE"
        
        )
    
    PARAM = bpy.props.StringProperty(
        name="PARAM"
        ,default=""
        ,subtype="NONE"
        ,maxlen=0
        ,description="The NODE"
        
        )
    
    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    TYPE_items = [
        ("show_screen", "show_screen", "show_screen"),
        ("hide_screen", "hide_screen", "hide_screen"),
        ("show_document", "show_document", "show_document"),
        ("hide_document", "hide_document", "hide_document"),
        ("show", "show", "show"),
        ("hide", "hide", "hide"),
        ("hover", "hover", "hover"),
        ("clicked", "clicked", "clicked"),

    ]
    TYPE = bpy.props.EnumProperty(description="null", items=TYPE_items, default="show_screen")
    
    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "ENABLED",

            ]        
    outputsockets=[
             "VALUE",

            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        ENABLED = self.inputs.new('NodeTreeBOOL', "ENABLED")

        VALUE=self.outputs.new('NodeTreeBOOL', "VALUE")
        
        try:
            ScreenAction_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'ScreenAction',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'ScreenAction',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'ScreenAction',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop(self, "TYPE")

        layout.prop(self, "DOC")

        layout.prop(self, "PARAM")

        try:
            ScreenAction_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop(self, "TYPE")

        layout.prop(self, "DOC")

        layout.prop(self, "PARAM")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            ScreenAction_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return ScreenAction_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "ENABLED" not in keys:
            ENABLED = self.inputs.new('NodeTreeBOOL', "ENABLED")

        keys = self.outputs.keys()
      
        if "VALUE" not in keys:
            VALUE=self.outputs.new('NodeTreeBOOL', "VALUE")
        
# Derived from the Node base type.
class Element(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''null'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'Element'
    # Label for nice name display
    bl_label = 'Element'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    ID = bpy.props.StringProperty(
        name="ID"
        ,default=""
        ,subtype="NONE"
        ,maxlen=0
        ,description="The NODE"
        
        )
    
    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "SCREEN",

            ]        
    outputsockets=[
             
            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        SCREEN = self.inputs.new('NodeTreeBOOL', "SCREEN")

        try:
            Element_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'Element',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'Element',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'Element',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop(self, "ID")

        try:
            Element_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop(self, "ID")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            Element_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return Element_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "SCREEN" not in keys:
            SCREEN = self.inputs.new('NodeTreeBOOL', "SCREEN")

        keys = self.outputs.keys()

# Derived from the Node base type.
class AnimationDefinition(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''null'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'AnimationDefinition'
    # Label for nice name display
    bl_label = 'AnimationDefinition'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    #wrapper to the implemented update-call, to ensure no exception will be thrown
    def AnimationDefinition_NAME_updateCaller(self,context):
        try:
            print("Check for logic:"+str(type(self)))
            logic = runtimedata.RuntimeData.runtime.getLogic(self.bpid)
            if logic:
                try: # first check if there is a corresponding method in the logic 
                    logic.update_NAME(self,context) 
                    return
                except:
                    print (traceback.format_exc())
                    pass
            else:
                print("NO LOGIC")
            # now try it the old way
            AnimationDefinition_NAME_update(self,context)
        except:
            print(traceback.format_exc())
            
    NAME = bpy.props.StringProperty(
        name="NAME"
        ,default=""
        ,subtype="NONE"
        ,maxlen=0
        ,description="The NODE"

        ,update=AnimationDefinition_NAME_updateCaller
        
        )
    
    ANIM_NAME = bpy.props.StringProperty(
        name="ANIM_NAME"
        ,default=""
        ,subtype="NONE"
        ,maxlen=0
        ,description="The NODE"
        
        )
    
    RAW_ANIM_NAME = bpy.props.StringProperty(
        name="RAW_ANIM_NAME"
        ,default=""
        ,subtype="NONE"
        ,maxlen=0
        ,description="The NODE"
        
        )
    
    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    FRAME_CUSTOM = bpy.props.BoolProperty(
        name="FRAME_CUSTOM"

        ,default=0
        
        ,subtype="NONE"
     
        ,description="no desc"

        )

    FRAME_START = bpy.props.IntProperty(
        name="FRAME_START"

        ,default=0
        
        ,subtype="NONE"
     
        ,description="no desc"

        )

    FRAME_END = bpy.props.IntProperty(
        name="FRAME_END"

        ,default=2
        
        ,subtype="NONE"
     
        ,description="no desc"

        )

    SPEED = bpy.props.FloatProperty(
        name="SPEED"

        ,default=1.0
        
        ,subtype="NONE"

        ,unit="NONE"
        ,precision=2
     
        ,description="no desc"

        )

    RESET_ONSTOP = bpy.props.BoolProperty(
        name="RESET_ONSTOP"

        ,default=0
        
        ,subtype="NONE"
     
        ,description="Reset animation on stop?"

        )

    RESET_ONSTART = bpy.props.BoolProperty(
        name="RESET_ONSTART"

        ,default=0
        
        ,subtype="NONE"
     
        ,description="Reset animation on stop?"

        )

    BLEND = bpy.props.IntProperty(
        name="BLEND"

        ,default=0
        
        ,subtype="NONE"
     
        ,description="How many frames should be blended?"

        )
  
    MODE_items = [
        ("loop", "loop", "Reset loop when done"),
        ("end", "end", "Play till end and stop"),
        ("inverse", "inverse", "Invert Frames"),

    ]
    MODE = bpy.props.EnumProperty(description="null", items=MODE_items, default="loop")
    
    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "TARGET",

            ]        
    outputsockets=[
             "TRIGGERS",

            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        TARGET = self.inputs.new('NodeTreeObject', "TARGET")

        TRIGGERS=self.outputs.new('NodeTreeBOOL', "TRIGGERS")
        
        try:
            AnimationDefinition_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'AnimationDefinition',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'AnimationDefinition',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'AnimationDefinition',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop(self, "NAME")

        layout.prop(self, "MODE")

        layout.prop(self, "SPEED")

        layout.prop(self, "RESET_ONSTOP")

        layout.prop(self, "RESET_ONSTART")

        layout.prop(self, "BLEND")

        layout.prop_search(self, "ANIM_NAME", bpy.data, "actions", icon="ACTION")

        try:
            AnimationDefinition_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop(self, "NAME")

        layout.prop(self, "RAW_ANIM_NAME")

        layout.prop(self, "MODE")

        layout.prop(self, "SPEED")

        layout.prop(self, "RESET_ONSTOP")

        layout.prop(self, "RESET_ONSTART")

        layout.prop(self, "BLEND")

        layout.prop_search(self, "ANIM_NAME", bpy.data, "actions", icon="ACTION")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            AnimationDefinition_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return AnimationDefinition_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "TARGET" not in keys:
            TARGET = self.inputs.new('NodeTreeObject', "TARGET")

        keys = self.outputs.keys()
      
        if "TRIGGERS" not in keys:
            TRIGGERS=self.outputs.new('NodeTreeBOOL', "TRIGGERS")
        
# Derived from the Node base type.
class AnimationPlayer(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''Play/Stop/Pause on of the defined Animations'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'AnimationPlayer'
    # Label for nice name display
    bl_label = 'AnimationPlayer'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    NAME = bpy.props.StringProperty(
        name="NAME"
        ,default=""
        ,subtype="NONE"
        ,maxlen=0
        ,description="The NODE"
        
        )
    
    RAW_ANIM_NAME = bpy.props.StringProperty(
        name="RAW_ANIM_NAME"
        ,default=""
        ,subtype="NONE"
        ,maxlen=0
        ,description="The NODE"
        
        )
    
    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "ENABLED",
"START",
"STOP",
"PAUSE",
"RESUME",
"RESET",

            ]        
    outputsockets=[
             "ENABLED",
"RUNNING",
"STOPPED",
"PAUSED",
"DONE_TRIGGER",
"LOOPEND_TRIGGER",

            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        ENABLED = self.inputs.new('NodeTreeBOOL', "ENABLED")

        START = self.inputs.new('NodeTreeBOOL', "START")

        STOP = self.inputs.new('NodeTreeBOOL', "STOP")

        PAUSE = self.inputs.new('NodeTreeBOOL', "PAUSE")

        RESUME = self.inputs.new('NodeTreeBOOL', "RESUME")

        RESET = self.inputs.new('NodeTreeBOOL', "RESET")

        ENABLED=self.outputs.new('NodeTreeBOOL', "ENABLED")
        
        RUNNING=self.outputs.new('NodeTreeBOOL', "RUNNING")
        
        STOPPED=self.outputs.new('NodeTreeBOOL', "STOPPED")
        
        PAUSED=self.outputs.new('NodeTreeBOOL', "PAUSED")
        
        DONE_TRIGGER=self.outputs.new('NodeTreeBOOL', "DONE_TRIGGER")
        
        LOOPEND_TRIGGER=self.outputs.new('NodeTreeBOOL', "LOOPEND_TRIGGER")
        
        try:
            AnimationPlayer_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'AnimationPlayer',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'AnimationPlayer',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'AnimationPlayer',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        try:
            AnimationPlayer_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop(self, "NAME")

        layout.prop(self, "RAW_ANIM_NAME")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            AnimationPlayer_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return AnimationPlayer_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "ENABLED" not in keys:
            ENABLED = self.inputs.new('NodeTreeBOOL', "ENABLED")

        if "START" not in keys:
            START = self.inputs.new('NodeTreeBOOL', "START")

        if "STOP" not in keys:
            STOP = self.inputs.new('NodeTreeBOOL', "STOP")

        if "PAUSE" not in keys:
            PAUSE = self.inputs.new('NodeTreeBOOL', "PAUSE")

        if "RESUME" not in keys:
            RESUME = self.inputs.new('NodeTreeBOOL', "RESUME")

        if "RESET" not in keys:
            RESET = self.inputs.new('NodeTreeBOOL', "RESET")

        keys = self.outputs.keys()
      
        if "ENABLED" not in keys:
            ENABLED=self.outputs.new('NodeTreeBOOL', "ENABLED")
        
        if "RUNNING" not in keys:
            RUNNING=self.outputs.new('NodeTreeBOOL', "RUNNING")
        
        if "STOPPED" not in keys:
            STOPPED=self.outputs.new('NodeTreeBOOL', "STOPPED")
        
        if "PAUSED" not in keys:
            PAUSED=self.outputs.new('NodeTreeBOOL', "PAUSED")
        
        if "DONE_TRIGGER" not in keys:
            DONE_TRIGGER=self.outputs.new('NodeTreeBOOL', "DONE_TRIGGER")
        
        if "LOOPEND_TRIGGER" not in keys:
            LOOPEND_TRIGGER=self.outputs.new('NodeTreeBOOL', "LOOPEND_TRIGGER")
        
# Derived from the Node base type.
class AnimationTrigger(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''NOT IMPLEMENTED,YET'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'AnimationTrigger'
    # Label for nice name display
    bl_label = 'AnimationTrigger'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    frame = bpy.props.IntProperty(
        name="frame"
        
        ,subtype="NONE"
     
        ,description="no desc"

        )
  
    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "ANIMATION",

            ]        
    outputsockets=[
             "TRIGGERED",
"NOT_TRIGGERED",

            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        ANIMATION = self.inputs.new('NodeTreeBOOL', "ANIMATION")

        TRIGGERED=self.outputs.new('NodeTreeBOOL', "TRIGGERED")
        
        NOT_TRIGGERED=self.outputs.new('NodeTreeBOOL', "NOT_TRIGGERED")
        
        try:
            AnimationTrigger_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'AnimationTrigger',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'AnimationTrigger',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'AnimationTrigger',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop(self, "frame")

        try:
            AnimationTrigger_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop(self, "frame")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            AnimationTrigger_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return AnimationTrigger_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "ANIMATION" not in keys:
            ANIMATION = self.inputs.new('NodeTreeBOOL', "ANIMATION")

        keys = self.outputs.keys()
      
        if "TRIGGERED" not in keys:
            TRIGGERED=self.outputs.new('NodeTreeBOOL', "TRIGGERED")
        
        if "NOT_TRIGGERED" not in keys:
            NOT_TRIGGERED=self.outputs.new('NodeTreeBOOL', "NOT_TRIGGERED")
        
# Derived from the Node base type.
class CollisionNode(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''null'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'CollisionNode'
    # Label for nice name display
    bl_label = 'CollisionNode'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    PROPERTY = bpy.props.StringProperty(
        name="PROPERTY"
        ,default=""
        ,subtype="NONE"
        ,maxlen=0
        ,description="The NODE"
        
        )
    
    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "ENABLED",
"TARGET",
"COLLIDES_WITH",

            ]        
    outputsockets=[
             "HAS_COLLIDED",
"NOT_HAS_COLLIDED",
"COLLIDED_OBJ",
"CONTACT_POSITION",

            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        ENABLED = self.inputs.new('NodeTreeBOOL', "ENABLED")

        TARGET = self.inputs.new('NodeTreeObject', "TARGET")

        COLLIDES_WITH = self.inputs.new('NodeTreeObject', "COLLIDES_WITH")

        HAS_COLLIDED=self.outputs.new('NodeTreeBOOL', "HAS_COLLIDED")
        
        NOT_HAS_COLLIDED=self.outputs.new('NodeTreeBOOL', "NOT_HAS_COLLIDED")
        
        COLLIDED_OBJ=self.outputs.new('NodeTreeSTRING', "COLLIDED_OBJ")
        
        CONTACT_POSITION=self.outputs.new('NodeTreeVec3', "CONTACT_POSITION")
        
        try:
            CollisionNode_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'CollisionNode',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'CollisionNode',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'CollisionNode',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop(self, "PROPERTY")

        try:
            CollisionNode_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop(self, "PROPERTY")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            CollisionNode_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return CollisionNode_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "ENABLED" not in keys:
            ENABLED = self.inputs.new('NodeTreeBOOL', "ENABLED")

        if "TARGET" not in keys:
            TARGET = self.inputs.new('NodeTreeObject', "TARGET")

        if "COLLIDES_WITH" not in keys:
            COLLIDES_WITH = self.inputs.new('NodeTreeObject', "COLLIDES_WITH")

        keys = self.outputs.keys()
      
        if "HAS_COLLIDED" not in keys:
            HAS_COLLIDED=self.outputs.new('NodeTreeBOOL', "HAS_COLLIDED")
        
        if "NOT_HAS_COLLIDED" not in keys:
            NOT_HAS_COLLIDED=self.outputs.new('NodeTreeBOOL', "NOT_HAS_COLLIDED")
        
        if "COLLIDED_OBJ" not in keys:
            COLLIDED_OBJ=self.outputs.new('NodeTreeSTRING', "COLLIDED_OBJ")
        
        if "CONTACT_POSITION" not in keys:
            CONTACT_POSITION=self.outputs.new('NodeTreeVec3', "CONTACT_POSITION")
        
# Derived from the Node base type.
class FileNode(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''null'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'FileNode'
    # Label for nice name display
    bl_label = 'FileNode'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    File = bpy.props.StringProperty(
        name="File"
        ,default=""
        ,subtype="FILE_PATH"
        ,maxlen=0
        ,description="The NODE"
        
        )
    
    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "FILE",

            ]        
    outputsockets=[
             "FILE",

            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        FILE = self.inputs.new('NodeTreeBOOL', "FILE")

        FILE=self.outputs.new('NodeTreeBOOL', "FILE")
        
        try:
            FileNode_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'FileNode',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'FileNode',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'FileNode',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop(self, "File")

        try:
            FileNode_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop(self, "File")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            FileNode_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return FileNode_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "FILE" not in keys:
            FILE = self.inputs.new('NodeTreeBOOL', "FILE")

        keys = self.outputs.keys()
      
        if "FILE" not in keys:
            FILE=self.outputs.new('NodeTreeBOOL', "FILE")
        
# Derived from the Node base type.
class LuaNode(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''null'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'LuaNode'
    # Label for nice name display
    bl_label = 'LuaNode'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    TYPE = bpy.props.StringProperty(
        name="TYPE"
        ,default=""
        ,subtype="NONE"
        ,maxlen=0
        ,description="The NODE"
        
        )
    
    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             
            ]        
    outputsockets=[
             
            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        self.use_custom_color=True
        self.color=(0.1,0.6,0.15)
        
        try:
            LuaNode_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'LuaNode',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'LuaNode',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'LuaNode',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop(self, "TYPE")

        try:
            LuaNode_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop(self, "TYPE")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            LuaNode_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return LuaNode_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
      
        keys = self.outputs.keys()

# Derived from the Node base type.
class AdditionNode(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''null'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'AdditionNode'
    # Label for nice name display
    bl_label = 'Addition'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    LUACLASS = bpy.props.StringProperty(
        name="LUACLASS"
        ,default=""
        ,subtype="NONE"
        ,maxlen=0
        ,description="The NODE"
        
        )
    
    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    IVal = bpy.props.IntProperty(
        name="IVal"
        
        ,subtype="NONE"
     
        ,description="no desc"

        )
  
    TYPE_items = [
        ("float", "float", "FLOAT addition"),
        ("int", "float", "FLOAT addition"),
        ("bool", "float", "FLOAT addition"),

    ]
    TYPE = bpy.props.EnumProperty(description="null", items=TYPE_items, default="float")
    
    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "A",
"B",
"OBJ",

            ]        
    outputsockets=[
             "RESULT",

            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        A = self.inputs.new('NodeTreeFLOAT', "A")

        B = self.inputs.new('NodeTreeFLOAT', "B")

        OBJ = self.inputs.new('NodeTreeSTRING', "OBJ")

        RESULT=self.outputs.new('NodeTreeFLOAT', "RESULT")
        
        try:
            AdditionNode_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'AdditionNode',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'AdditionNode',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'AdditionNode',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop(self, "TYPE")

        layout.prop(self, "IVal")

        layout.prop(self, "LUACLASS")

        try:
            AdditionNode_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop(self, "TYPE")

        layout.prop(self, "IVal")

        layout.prop(self, "LUACLASS")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            AdditionNode_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return AdditionNode_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "A" not in keys:
            A = self.inputs.new('NodeTreeFLOAT', "A")

        if "B" not in keys:
            B = self.inputs.new('NodeTreeFLOAT', "B")

        if "OBJ" not in keys:
            OBJ = self.inputs.new('NodeTreeSTRING', "OBJ")

        keys = self.outputs.keys()
      
        if "RESULT" not in keys:
            RESULT=self.outputs.new('NodeTreeFLOAT', "RESULT")
        
# Derived from the Node base type.
class PrintNode(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''Print text to stdout!'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'PrintNode'
    # Label for nice name display
    bl_label = 'Print Node'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    PREFIX = bpy.props.StringProperty(
        name="PREFIX"
        ,default=""
        ,subtype="NONE"
        ,maxlen=0
        ,description="The NODE"
        
        )
    
    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    ON_CHANGE = bpy.props.BoolProperty(
        name="ON_CHANGE"

        ,default=0
        
        ,subtype="NONE"
     
        ,description="Only print if the value changed"

        )
  
    MODE_items = [
        ("only_screen", "only_screen", "only_screen"),
        ("only_log", "only_log", "only_log"),
        ("log_screen", "log + screen", "log + screen"),

    ]
    MODE = bpy.props.EnumProperty(description="null", items=MODE_items, default="only_screen")
    
    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "TEXT",
"DOPRINT",

            ]        
    outputsockets=[
             
            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        TEXT = self.inputs.new('NodeTreeSTRING', "TEXT")

        DOPRINT = self.inputs.new('NodeTreeBOOL', "DOPRINT")

        try:
            PrintNode_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'PrintNode',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'PrintNode',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'PrintNode',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop(self, "MODE")

        layout.prop(self, "ON_CHANGE")

        layout.prop(self, "PREFIX")

        try:
            PrintNode_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop(self, "MODE")

        layout.prop(self, "ON_CHANGE")

        layout.prop(self, "PREFIX")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            PrintNode_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return PrintNode_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "TEXT" not in keys:
            TEXT = self.inputs.new('NodeTreeSTRING', "TEXT")

        if "DOPRINT" not in keys:
            DOPRINT = self.inputs.new('NodeTreeBOOL', "DOPRINT")

        keys = self.outputs.keys()

# Derived from the Node base type.
class KeyNode(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''Check mouse button!'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'KeyNode'
    # Label for nice name display
    bl_label = 'Key Node'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    Delay = bpy.props.FloatProperty(
        name="Delay"
        
        ,subtype="NONE"

        ,unit="NONE"
        ,precision=0
     
        ,description="no desc"

        )
  
    Key_items = [
        ("none", "none", "none"),
        ("a", "a", "a"),
        ("b", "b", "b"),
        ("c", "c", "c"),
        ("d", "d", "d"),
        ("e", "e", "e"),
        ("f", "f", "f"),
        ("g", "g", "g"),
        ("h", "h", "h"),
        ("i", "i", "i"),
        ("j", "j", "j"),
        ("k", "k", "k"),
        ("l", "l", "l"),
        ("m", "m", "m"),
        ("n", "n", "n"),
        ("o", "o", "o"),
        ("p", "p", "p"),
        ("q", "q", "q"),
        ("r", "r", "r"),
        ("s", "s", "s"),
        ("t", "t", "t"),
        ("u", "u", "u"),
        ("v", "v", "v"),
        ("w", "w", "w"),
        ("x", "x", "x"),
        ("y", "y", "y"),
        ("z", "z", "z"),
        ("0", "0", "0"),
        ("1", "1", "1"),
        ("2", "2", "2"),
        ("3", "3", "3"),
        ("4", "4", "4"),
        ("5", "5", "5"),
        ("6", "6", "6"),
        ("7", "7", "7"),
        ("8", "8", "8"),
        ("9", "9", "9"),
        ("CAPSLOCK", "CAPSLOCK", "CAPSLOCK"),
        ("LEFTCTRL", "LEFTCTRL", "LEFTCTRL"),
        ("LEFTALT", "LEFTALT", "LEFTALT"),
        ("RIGHTALT", "RIGHTALT", "RIGHTALT"),
        ("RIGHTCTRL", "RIGHTCTRL", "RIGHTCTRL"),
        ("RIGHTSHIFT", "RIGHTSHIFT", "RIGHTSHIFT"),
        ("LEFTSHIFT", "LEFTSHIFT", "LEFTSHIFT"),
        ("ESC", "ESC", "ESC"),
        ("TAB", "TAB", "TAB"),
        ("RET", "RET", "RET"),
        ("SPACE", "SPACE", "SPACE"),
        ("LINEFEED", "LINEFEED", "LINEFEED"),
        ("BACKSPACE", "BACKSPACE", "BACKSPACE"),
        ("DEL", "DEL", "DEL"),
        ("SEMICOLON", "SEMICOLON", "SEMICOLON"),
        ("PERIOD", "PERIOD", "PERIOD"),
        ("COMMA", "COMMA", "COMMA"),
        ("QUOTE", "QUOTE", "QUOTE"),
        ("ACCENTGRAVE", "ACCENTGRAVE", "ACCENTGRAVE"),
        ("MINUS", "MINUS", "MINUS"),
        ("SLASH", "SLASH", "SLASH"),
        ("BACKSLASH", "BACKSLASH", "BACKSLASH"),
        ("EQUAL", "EQUAL", "EQUAL"),
        ("LEFTBRACKET", "LEFTBRACKET", "LEFTBRACKET"),
        ("RIGHTBRACKET", "RIGHTBRACKET", "RIGHTBRACKET"),
        ("LEFTARROW", "LEFTARROW", "LEFTARROW"),
        ("DOWNARROW", "DOWNARROW", "DOWNARROW"),
        ("RIGHTARROW", "RIGHTARROW", "RIGHTARROW"),
        ("UPARROW", "UPARROW", "UPARROW"),
        ("PAD0", "PAD0", "PAD0"),
        ("PAD1", "PAD1", "PAD1"),
        ("PAD2", "PAD2", "PAD2"),
        ("PAD3", "PAD3", "PAD3"),
        ("PAD4", "PAD4", "PAD4"),
        ("PAD5", "PAD5", "PAD5"),
        ("PAD6", "PAD6", "PAD6"),
        ("PAD7", "PAD7", "PAD7"),
        ("PAD8", "PAD8", "PAD8"),
        ("PAD9", "PAD9", "PAD9"),
        ("PADEQUALS", "PADEQUALS", "PADEQUALS"),
        ("PADPERIOD", "PADPERIOD", "PADPERIOD"),
        ("PADSLASH", "PADSLASH", "PADSLASH"),
        ("PADASTER", "PADASTER", "PADASTER"),
        ("PADMINUS", "PADMINUS", "PADMINUS"),
        ("PADENTER", "PADENTER", "PADENTER"),
        ("PADPLUS", "PADPLUS", "PADPLUS"),
        ("F1", "F1", "F1"),
        ("F2", "F2", "F2"),
        ("F3", "F3", "F3"),
        ("F4", "F4", "F4"),
        ("F5", "F5", "F5"),
        ("F6", "F6", "F6"),
        ("F7", "F7", "F7"),
        ("F8", "F8", "F8"),
        ("F9", "F9", "F9"),
        ("F10", "F10", "F10"),
        ("F11", "F11", "F11"),
        ("F12", "F12", "F12"),
        ("PAUSE", "PAUSE", "PAUSE"),
        ("INSERT", "INSERT", "INSERT"),
        ("HOME", "HOME", "HOME"),
        ("PAGEUP", "PAGEUP", "PAGEUP"),
        ("PAGEDOWN", "PAGEDOWN", "PAGEDOWN"),
        ("END", "END", "END"),
        ("UNKNOWN", "UNKNOWN", "UNKNOWN"),
        ("COMMAND", "COMMAND", "COMMAND"),
        ("GRLESS", "GRLESS", "GRLESS"),
        ("MAX", "MAX", "MAX"),

    ]
    Key = bpy.props.EnumProperty(description="null", items=Key_items, default="none")
    
    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "UPDATE",

            ]        
    outputsockets=[
             "IS_DOWN",
"NOT_DOWN",
"PRESSED",
"RELEASED",

            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        UPDATE = self.inputs.new('NodeTreeBOOL', "UPDATE")

        IS_DOWN=self.outputs.new('NodeTreeBOOL', "IS_DOWN")
        
        NOT_DOWN=self.outputs.new('NodeTreeBOOL', "NOT_DOWN")
        
        PRESSED=self.outputs.new('NodeTreeBOOL', "PRESSED")
        
        RELEASED=self.outputs.new('NodeTreeBOOL', "RELEASED")
        
        try:
            KeyNode_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'KeyNode',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'KeyNode',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'KeyNode',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop(self, "Key")

        layout.prop(self, "Delay")

        try:
            KeyNode_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop(self, "Key")

        layout.prop(self, "Delay")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            KeyNode_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return KeyNode_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "UPDATE" not in keys:
            UPDATE = self.inputs.new('NodeTreeBOOL', "UPDATE")

        keys = self.outputs.keys()
      
        if "IS_DOWN" not in keys:
            IS_DOWN=self.outputs.new('NodeTreeBOOL', "IS_DOWN")
        
        if "NOT_DOWN" not in keys:
            NOT_DOWN=self.outputs.new('NodeTreeBOOL', "NOT_DOWN")
        
        if "PRESSED" not in keys:
            PRESSED=self.outputs.new('NodeTreeBOOL', "PRESSED")
        
        if "RELEASED" not in keys:
            RELEASED=self.outputs.new('NodeTreeBOOL', "RELEASED")
        
# Derived from the Node base type.
class MouseButton(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''Check mouse button!'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'MouseButton'
    # Label for nice name display
    bl_label = 'MouseButton'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    Delay = bpy.props.FloatProperty(
        name="Delay"
        
        ,subtype="NONE"

        ,unit="NONE"
        ,precision=0
     
        ,description="no desc"

        )
  
    Button_items = [
        ("left", "left", "left"),
        ("right", "right", "right"),
        ("middle", "middle", "middle"),

    ]
    Button = bpy.props.EnumProperty(description="null", items=Button_items, default="left")
    
    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "UPDATE",

            ]        
    outputsockets=[
             "IS_DOWN",
"NOT_DOWN",
"PRESSED",
"RELEASED",

            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        UPDATE = self.inputs.new('NodeTreeBOOL', "UPDATE")

        IS_DOWN=self.outputs.new('NodeTreeBOOL', "IS_DOWN")
        
        NOT_DOWN=self.outputs.new('NodeTreeBOOL', "NOT_DOWN")
        
        PRESSED=self.outputs.new('NodeTreeBOOL', "PRESSED")
        
        RELEASED=self.outputs.new('NodeTreeBOOL', "RELEASED")
        
        try:
            MouseButton_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'MouseButton',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'MouseButton',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'MouseButton',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop(self, "Button")

        layout.prop(self, "Delay")

        try:
            MouseButton_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop(self, "Button")

        layout.prop(self, "Delay")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            MouseButton_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return MouseButton_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "UPDATE" not in keys:
            UPDATE = self.inputs.new('NodeTreeBOOL', "UPDATE")

        keys = self.outputs.keys()
      
        if "IS_DOWN" not in keys:
            IS_DOWN=self.outputs.new('NodeTreeBOOL', "IS_DOWN")
        
        if "NOT_DOWN" not in keys:
            NOT_DOWN=self.outputs.new('NodeTreeBOOL', "NOT_DOWN")
        
        if "PRESSED" not in keys:
            PRESSED=self.outputs.new('NodeTreeBOOL', "PRESSED")
        
        if "RELEASED" not in keys:
            RELEASED=self.outputs.new('NodeTreeBOOL', "RELEASED")
        
# Derived from the Node base type.
class DeltaNode(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''null'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'DeltaNode'
    # Label for nice name display
    bl_label = 'DeltaNode'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    DAMPING = bpy.props.FloatProperty(
        name="DAMPING"

        ,default=0.1
        
        ,subtype="NONE"

        ,unit="NONE"
        ,precision=0
     
        ,description="no desc"

        )
  
    TYPE_items = [
        ("translation", "translation", "translation"),
        ("rotation", "rotation", "rotation"),
        ("scale", "scale", "scale"),

    ]
    TYPE = bpy.props.EnumProperty(description="null", items=TYPE_items, default="translation")
    
    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "ENABLED",
"FOLLOW_OBJ",
"TARGET_OBJ",

            ]        
    outputsockets=[
             
            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        ENABLED = self.inputs.new('NodeTreeBOOL', "ENABLED")

        FOLLOW_OBJ = self.inputs.new('NodeTreeSTRING', "FOLLOW_OBJ")

        TARGET_OBJ = self.inputs.new('NodeTreeSTRING', "TARGET_OBJ")

        try:
            DeltaNode_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'DeltaNode',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'DeltaNode',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'DeltaNode',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop(self, "TYPE")

        layout.prop(self, "DAMPING")

        try:
            DeltaNode_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop(self, "TYPE")

        layout.prop(self, "DAMPING")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            DeltaNode_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return DeltaNode_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "ENABLED" not in keys:
            ENABLED = self.inputs.new('NodeTreeBOOL', "ENABLED")

        if "FOLLOW_OBJ" not in keys:
            FOLLOW_OBJ = self.inputs.new('NodeTreeSTRING', "FOLLOW_OBJ")

        if "TARGET_OBJ" not in keys:
            TARGET_OBJ = self.inputs.new('NodeTreeSTRING', "TARGET_OBJ")

        keys = self.outputs.keys()

# Derived from the Node base type.
class TypeColor(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''null'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'TypeColor'
    # Label for nice name display
    bl_label = 'Color'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "R",
"G",
"B",
"A",

            ]        
    outputsockets=[
             "COLOR",

            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        R = self.inputs.new('NodeTreeFLOAT', "R")

        G = self.inputs.new('NodeTreeFLOAT', "G")

        B = self.inputs.new('NodeTreeFLOAT', "B")

        A = self.inputs.new('NodeTreeFLOAT', "A")

        COLOR=self.outputs.new('NodeTreeCOLOR', "COLOR")
        
        try:
            TypeColor_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'TypeColor',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'TypeColor',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'TypeColor',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        try:
            TypeColor_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            TypeColor_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return TypeColor_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "R" not in keys:
            R = self.inputs.new('NodeTreeFLOAT', "R")

        if "G" not in keys:
            G = self.inputs.new('NodeTreeFLOAT', "G")

        if "B" not in keys:
            B = self.inputs.new('NodeTreeFLOAT', "B")

        if "A" not in keys:
            A = self.inputs.new('NodeTreeFLOAT', "A")

        keys = self.outputs.keys()
      
        if "COLOR" not in keys:
            COLOR=self.outputs.new('NodeTreeCOLOR', "COLOR")
        
# Derived from the Node base type.
class TypeInt(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''Variable Node'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'TypeInt'
    # Label for nice name display
    bl_label = 'Integer'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "VAL",

            ]        
    outputsockets=[
             "VAL",

            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        VAL = self.inputs.new('NodeTreeINT', "VAL")

        VAL=self.outputs.new('NodeTreeINT', "VAL")
        
        try:
            TypeInt_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'TypeInt',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'TypeInt',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'TypeInt',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        try:
            TypeInt_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            TypeInt_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return TypeInt_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "VAL" not in keys:
            VAL = self.inputs.new('NodeTreeINT', "VAL")

        keys = self.outputs.keys()
      
        if "VAL" not in keys:
            VAL=self.outputs.new('NodeTreeINT', "VAL")
        
# Derived from the Node base type.
class TypeFloat(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''Variable Node'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'TypeFloat'
    # Label for nice name display
    bl_label = 'Float'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "VAL",

            ]        
    outputsockets=[
             "VAL",

            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        VAL = self.inputs.new('NodeTreeFLOAT', "VAL")

        VAL=self.outputs.new('NodeTreeFLOAT', "VAL")
        
        try:
            TypeFloat_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'TypeFloat',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'TypeFloat',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'TypeFloat',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        try:
            TypeFloat_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            TypeFloat_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return TypeFloat_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "VAL" not in keys:
            VAL = self.inputs.new('NodeTreeFLOAT', "VAL")

        keys = self.outputs.keys()
      
        if "VAL" not in keys:
            VAL=self.outputs.new('NodeTreeFLOAT', "VAL")
        
# Derived from the Node base type.
class TypeBool(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''Variable Node'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'TypeBool'
    # Label for nice name display
    bl_label = 'Bool'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "VAL",

            ]        
    outputsockets=[
             "VAL",

            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        VAL = self.inputs.new('NodeTreeBOOL', "VAL")

        VAL=self.outputs.new('NodeTreeBOOL', "VAL")
        
        try:
            TypeBool_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'TypeBool',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'TypeBool',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'TypeBool',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        try:
            TypeBool_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            TypeBool_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return TypeBool_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "VAL" not in keys:
            VAL = self.inputs.new('NodeTreeBOOL', "VAL")

        keys = self.outputs.keys()
      
        if "VAL" not in keys:
            VAL=self.outputs.new('NodeTreeBOOL', "VAL")
        
# Derived from the Node base type.
class PBSMaterial(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''null'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'PBSMaterial'
    # Label for nice name display
    bl_label = 'PBSMaterial'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "ENABLED",
"ALBEDO_COL",
"F0_COL",
"ROUGH",
"LR_OFFSET",

            ]        
    outputsockets=[
             "SLOT_MAIN",
"SLOT_D1",
"SLOT_D2",
"ENV_MAP",

            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        ENABLED = self.inputs.new('NodeTreeBOOL', "ENABLED")

        ALBEDO_COL = self.inputs.new('NodeTreeCOLOR', "ALBEDO_COL")
        
        ALBEDO_COL.value = (1,1,1,1)

        F0_COL = self.inputs.new('NodeTreeCOLOR', "F0_COL")
        
        F0_COL.value = (0.01,0.01,0.01,1)

        ROUGH = self.inputs.new('NodeTreeFLOAT', "ROUGH")

        LR_OFFSET = self.inputs.new('NodeTreeFLOAT', "LR_OFFSET")

        SLOT_MAIN=self.outputs.new('NodeTreeBOOL', "SLOT_MAIN")
        
        SLOT_D1=self.outputs.new('NodeTreeBOOL', "SLOT_D1")
        
        SLOT_D2=self.outputs.new('NodeTreeBOOL', "SLOT_D2")
        
        ENV_MAP=self.outputs.new('NodeTreeBOOL', "ENV_MAP")
        
        try:
            PBSMaterial_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'PBSMaterial',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'PBSMaterial',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'PBSMaterial',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        try:
            PBSMaterial_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            PBSMaterial_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return PBSMaterial_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "ENABLED" not in keys:
            ENABLED = self.inputs.new('NodeTreeBOOL', "ENABLED")

        if "ALBEDO_COL" not in keys:
            ALBEDO_COL = self.inputs.new('NodeTreeCOLOR', "ALBEDO_COL")

        if "F0_COL" not in keys:
            F0_COL = self.inputs.new('NodeTreeCOLOR', "F0_COL")

        if "ROUGH" not in keys:
            ROUGH = self.inputs.new('NodeTreeFLOAT', "ROUGH")

        if "LR_OFFSET" not in keys:
            LR_OFFSET = self.inputs.new('NodeTreeFLOAT', "LR_OFFSET")

        keys = self.outputs.keys()
      
        if "SLOT_MAIN" not in keys:
            SLOT_MAIN=self.outputs.new('NodeTreeBOOL', "SLOT_MAIN")
        
        if "SLOT_D1" not in keys:
            SLOT_D1=self.outputs.new('NodeTreeBOOL', "SLOT_D1")
        
        if "SLOT_D2" not in keys:
            SLOT_D2=self.outputs.new('NodeTreeBOOL', "SLOT_D2")
        
        if "ENV_MAP" not in keys:
            ENV_MAP=self.outputs.new('NodeTreeBOOL', "ENV_MAP")
        
# Derived from the Node base type.
class PBSSlot(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''null'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'PBSSlot'
    # Label for nice name display
    bl_label = 'PBSSlot'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "PBS_MAT",
"UV_MAP",
"OFFSET_X",
"OFFSET_Y",
"SCALE_X",
"SCALE_Y",

            ]        
    outputsockets=[
             "ALBEDO_MAP",
"NORMAL_MAP",
"F0_MAP",

            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        PBS_MAT = self.inputs.new('NodeTreeBOOL', "PBS_MAT")

        PBS_MAT.dataVisible = False

        UV_MAP = self.inputs.new('NodeTreeINT', "UV_MAP")

        OFFSET_X = self.inputs.new('NodeTreeFLOAT', "OFFSET_X")
        
        OFFSET_X.value = 0

        OFFSET_Y = self.inputs.new('NodeTreeFLOAT', "OFFSET_Y")
        
        OFFSET_Y.value = 0

        SCALE_X = self.inputs.new('NodeTreeFLOAT', "SCALE_X")
        
        SCALE_X.value = 1

        SCALE_Y = self.inputs.new('NodeTreeFLOAT', "SCALE_Y")
        
        SCALE_Y.value = 1

        ALBEDO_MAP=self.outputs.new('NodeTreeBOOL', "ALBEDO_MAP")
        
        NORMAL_MAP=self.outputs.new('NodeTreeBOOL', "NORMAL_MAP")
        
        F0_MAP=self.outputs.new('NodeTreeBOOL', "F0_MAP")
        
        try:
            PBSSlot_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'PBSSlot',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'PBSSlot',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'PBSSlot',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        try:
            PBSSlot_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            PBSSlot_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return PBSSlot_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "PBS_MAT" not in keys:
            PBS_MAT = self.inputs.new('NodeTreeBOOL', "PBS_MAT")

        if "UV_MAP" not in keys:
            UV_MAP = self.inputs.new('NodeTreeINT', "UV_MAP")

        if "OFFSET_X" not in keys:
            OFFSET_X = self.inputs.new('NodeTreeFLOAT', "OFFSET_X")

        if "OFFSET_Y" not in keys:
            OFFSET_Y = self.inputs.new('NodeTreeFLOAT', "OFFSET_Y")

        if "SCALE_X" not in keys:
            SCALE_X = self.inputs.new('NodeTreeFLOAT', "SCALE_X")

        if "SCALE_Y" not in keys:
            SCALE_Y = self.inputs.new('NodeTreeFLOAT', "SCALE_Y")

        keys = self.outputs.keys()
      
        if "ALBEDO_MAP" not in keys:
            ALBEDO_MAP=self.outputs.new('NodeTreeBOOL', "ALBEDO_MAP")
        
        if "NORMAL_MAP" not in keys:
            NORMAL_MAP=self.outputs.new('NodeTreeBOOL', "NORMAL_MAP")
        
        if "F0_MAP" not in keys:
            F0_MAP=self.outputs.new('NodeTreeBOOL', "F0_MAP")
        
# Derived from the Node base type.
class PBSTex_Albedo(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''null'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'PBSTex_Albedo'
    # Label for nice name display
    bl_label = 'PBSTex_Albedo'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    #wrapper to the implemented update-call, to ensure no exception will be thrown
    def PBSTex_Albedo_ALBEDO_MAP_updateCaller(self,context):
        try:
            print("Check for logic:"+str(type(self)))
            logic = runtimedata.RuntimeData.runtime.getLogic(self.bpid)
            if logic:
                try: # first check if there is a corresponding method in the logic 
                    logic.update_ALBEDO_MAP(self,context) 
                    return
                except:
                    print (traceback.format_exc())
                    pass
            else:
                print("NO LOGIC")
            # now try it the old way
            PBSTex_Albedo_ALBEDO_MAP_update(self,context)
        except:
            print(traceback.format_exc())
            
    ALBEDO_MAP = bpy.props.StringProperty(
        name="ALBEDO_MAP"
        ,default=""
        ,subtype="NONE"
        ,maxlen=0
        ,description="The NODE"

        ,update=PBSTex_Albedo_ALBEDO_MAP_updateCaller
        
        )
    
    PATH = bpy.props.StringProperty(
        name="PATH"
        ,default=""
        ,subtype="NONE"
        ,maxlen=0
        ,description="The NODE"
        
        )
    
    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    BLEND_FUNC_items = [
        ("ALPHA", "ALPHA", "ALPHA"),
        ("ALPHA_PREMUL", "ALPHA_PREMUL", "ALPHA_PREMUL"),
        ("ADD", "ADD", "ADD"),
        ("SUBTRACT", "SUBTRACT", "SUBTRACT"),
        ("MULTIPLY", "MULTIPLY", "MULTIPLY"),
        ("MULTIPLY_2X", "MULTIPLY_2X", "MULTIPLY_2X"),
        ("SCREEN", "SCREEN", "SCREEN"),
        ("OVERLAY", "OVERLAY", "OVERLAY"),
        ("LIGHTEN", "LIGHTEN", "LIGHTEN"),
        ("DARKEN", "DARKEN", "DARKEN"),
        ("GRAIN_EXTRACT", "GRAIN_EXTRACT", "GRAIN_EXTRACT"),
        ("GRAIN_MERGE", "GRAIN_MERGE", "GRAIN_MERGE"),
        ("DIFFERENCE", "DIFFERENCE", "DIFFERENCE"),

    ]
    BLEND_FUNC = bpy.props.EnumProperty(description="null", items=BLEND_FUNC_items, default="ALPHA")
    
    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "SLOT",
"BLEND_FAC",

            ]        
    outputsockets=[
             
            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        SLOT = self.inputs.new('NodeTreeBOOL', "SLOT")

        SLOT.dataVisible = False

        BLEND_FAC = self.inputs.new('NodeTreeFLOAT', "BLEND_FAC")
        
        BLEND_FAC.value = 1

        try:
            PBSTex_Albedo_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'PBSTex_Albedo',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'PBSTex_Albedo',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'PBSTex_Albedo',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop(self, "BLEND_FUNC")

        layout.prop_search(self, "ALBEDO_MAP", bpy.data, "images", icon="OBJECT_DATA")

        try:
            PBSTex_Albedo_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop(self, "PATH")

        layout.prop(self, "BLEND_FUNC")

        layout.prop_search(self, "ALBEDO_MAP", bpy.data, "images", icon="OBJECT_DATA")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            PBSTex_Albedo_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return PBSTex_Albedo_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "SLOT" not in keys:
            SLOT = self.inputs.new('NodeTreeBOOL', "SLOT")

        if "BLEND_FAC" not in keys:
            BLEND_FAC = self.inputs.new('NodeTreeFLOAT', "BLEND_FAC")

        keys = self.outputs.keys()

# Derived from the Node base type.
class PBSTex_Env(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''null'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'PBSTex_Env'
    # Label for nice name display
    bl_label = 'PBSTex_Env'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    #wrapper to the implemented update-call, to ensure no exception will be thrown
    def PBSTex_Env_ENV_MAP_updateCaller(self,context):
        try:
            print("Check for logic:"+str(type(self)))
            logic = runtimedata.RuntimeData.runtime.getLogic(self.bpid)
            if logic:
                try: # first check if there is a corresponding method in the logic 
                    logic.update_ENV_MAP(self,context) 
                    return
                except:
                    print (traceback.format_exc())
                    pass
            else:
                print("NO LOGIC")
            # now try it the old way
            PBSTex_Env_ENV_MAP_update(self,context)
        except:
            print(traceback.format_exc())
            
    ENV_MAP = bpy.props.StringProperty(
        name="ENV_MAP"
        ,default=""
        ,subtype="NONE"
        ,maxlen=0
        ,description="The NODE"

        ,update=PBSTex_Env_ENV_MAP_updateCaller
        
        )
    
    PATH = bpy.props.StringProperty(
        name="PATH"
        ,default=""
        ,subtype="NONE"
        ,maxlen=0
        ,description="The NODE"
        
        )
    
    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "SLOT",
"INTENSITY_FAC",

            ]        
    outputsockets=[
             
            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        SLOT = self.inputs.new('NodeTreeBOOL', "SLOT")

        SLOT.dataVisible = False

        INTENSITY_FAC = self.inputs.new('NodeTreeFLOAT', "INTENSITY_FAC")
        
        INTENSITY_FAC.value = 1

        try:
            PBSTex_Env_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'PBSTex_Env',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'PBSTex_Env',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'PBSTex_Env',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop_search(self, "ENV_MAP", bpy.data, "images", icon="OBJECT_DATA")

        try:
            PBSTex_Env_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop(self, "PATH")

        layout.prop_search(self, "ENV_MAP", bpy.data, "images", icon="OBJECT_DATA")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            PBSTex_Env_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return PBSTex_Env_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "SLOT" not in keys:
            SLOT = self.inputs.new('NodeTreeBOOL', "SLOT")

        if "INTENSITY_FAC" not in keys:
            INTENSITY_FAC = self.inputs.new('NodeTreeFLOAT', "INTENSITY_FAC")

        keys = self.outputs.keys()

# Derived from the Node base type.
class PBSTex_Normal(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''null'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'PBSTex_Normal'
    # Label for nice name display
    bl_label = 'PBSTex_Normal'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    #wrapper to the implemented update-call, to ensure no exception will be thrown
    def PBSTex_Normal_NORMAL_MAP_updateCaller(self,context):
        try:
            print("Check for logic:"+str(type(self)))
            logic = runtimedata.RuntimeData.runtime.getLogic(self.bpid)
            if logic:
                try: # first check if there is a corresponding method in the logic 
                    logic.update_NORMAL_MAP(self,context) 
                    return
                except:
                    print (traceback.format_exc())
                    pass
            else:
                print("NO LOGIC")
            # now try it the old way
            PBSTex_Normal_NORMAL_MAP_update(self,context)
        except:
            print(traceback.format_exc())
            
    NORMAL_MAP = bpy.props.StringProperty(
        name="NORMAL_MAP"
        ,default=""
        ,subtype="NONE"
        ,maxlen=0
        ,description="The NODE"

        ,update=PBSTex_Normal_NORMAL_MAP_updateCaller
        
        )
    
    PATH = bpy.props.StringProperty(
        name="PATH"
        ,default=""
        ,subtype="NONE"
        ,maxlen=0
        ,description="The NODE"
        
        )
    
    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "SLOT",
"NORMAL_BLEND",
"R_BLEND",

            ]        
    outputsockets=[
             
            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        SLOT = self.inputs.new('NodeTreeBOOL', "SLOT")

        SLOT.dataVisible = False

        NORMAL_BLEND = self.inputs.new('NodeTreeFLOAT', "NORMAL_BLEND")
        
        NORMAL_BLEND.value = 1

        R_BLEND = self.inputs.new('NodeTreeFLOAT', "R_BLEND")
        
        R_BLEND.value = 1

        try:
            PBSTex_Normal_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'PBSTex_Normal',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'PBSTex_Normal',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'PBSTex_Normal',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop_search(self, "NORMAL_MAP", bpy.data, "images", icon="OBJECT_DATA")

        try:
            PBSTex_Normal_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop(self, "PATH")

        layout.prop_search(self, "NORMAL_MAP", bpy.data, "images", icon="OBJECT_DATA")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            PBSTex_Normal_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return PBSTex_Normal_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "SLOT" not in keys:
            SLOT = self.inputs.new('NodeTreeBOOL', "SLOT")

        if "NORMAL_BLEND" not in keys:
            NORMAL_BLEND = self.inputs.new('NodeTreeFLOAT', "NORMAL_BLEND")

        if "R_BLEND" not in keys:
            R_BLEND = self.inputs.new('NodeTreeFLOAT', "R_BLEND")

        keys = self.outputs.keys()

# Derived from the Node base type.
class PBSTex_F0(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''null'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'PBSTex_F0'
    # Label for nice name display
    bl_label = 'PBSTex_F0'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    #wrapper to the implemented update-call, to ensure no exception will be thrown
    def PBSTex_F0_F0_MAP_updateCaller(self,context):
        try:
            print("Check for logic:"+str(type(self)))
            logic = runtimedata.RuntimeData.runtime.getLogic(self.bpid)
            if logic:
                try: # first check if there is a corresponding method in the logic 
                    logic.update_F0_MAP(self,context) 
                    return
                except:
                    print (traceback.format_exc())
                    pass
            else:
                print("NO LOGIC")
            # now try it the old way
            PBSTex_F0_F0_MAP_update(self,context)
        except:
            print(traceback.format_exc())
            
    F0_MAP = bpy.props.StringProperty(
        name="F0_MAP"
        ,default=""
        ,subtype="NONE"
        ,maxlen=0
        ,description="The NODE"

        ,update=PBSTex_F0_F0_MAP_updateCaller
        
        )
    
    PATH = bpy.props.StringProperty(
        name="PATH"
        ,default=""
        ,subtype="NONE"
        ,maxlen=0
        ,description="The NODE"
        
        )
    
    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    BLEND_FUNC_items = [
        ("ALPHA", "ALPHA", "ALPHA"),
        ("ALPHA_PREMUL", "ALPHA_PREMUL", "ALPHA_PREMUL"),
        ("ADD", "ADD", "ADD"),
        ("SUBTRACT", "SUBTRACT", "SUBTRACT"),
        ("MULTIPLY", "MULTIPLY", "MULTIPLY"),
        ("MULTIPLY_2X", "MULTIPLY_2X", "MULTIPLY_2X"),
        ("SCREEN", "SCREEN", "SCREEN"),
        ("OVERLAY", "OVERLAY", "OVERLAY"),
        ("LIGHTEN", "LIGHTEN", "LIGHTEN"),
        ("DARKEN", "DARKEN", "DARKEN"),
        ("GRAIN_EXTRACT", "GRAIN_EXTRACT", "GRAIN_EXTRACT"),
        ("GRAIN_MERGE", "GRAIN_MERGE", "GRAIN_MERGE"),
        ("DIFFERENCE", "DIFFERENCE", "DIFFERENCE"),

    ]
    BLEND_FUNC = bpy.props.EnumProperty(description="null", items=BLEND_FUNC_items, default="ALPHA")
    
    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "SLOT",
"BLEND_FAC",

            ]        
    outputsockets=[
             
            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        SLOT = self.inputs.new('NodeTreeBOOL', "SLOT")

        SLOT.dataVisible = False

        BLEND_FAC = self.inputs.new('NodeTreeFLOAT', "BLEND_FAC")
        
        BLEND_FAC.value = 1

        try:
            PBSTex_F0_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'PBSTex_F0',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'PBSTex_F0',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'PBSTex_F0',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop(self, "BLEND_FUNC")

        layout.prop_search(self, "F0_MAP", bpy.data, "images", icon="OBJECT_DATA")

        try:
            PBSTex_F0_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop(self, "PATH")

        layout.prop(self, "BLEND_FUNC")

        layout.prop_search(self, "F0_MAP", bpy.data, "images", icon="OBJECT_DATA")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            PBSTex_F0_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return PBSTex_F0_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "SLOT" not in keys:
            SLOT = self.inputs.new('NodeTreeBOOL', "SLOT")

        if "BLEND_FAC" not in keys:
            BLEND_FAC = self.inputs.new('NodeTreeFLOAT', "BLEND_FAC")

        keys = self.outputs.keys()

# Derived from the Node base type.
class EngineNode(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''null'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'EngineNode'
    # Label for nice name display
    bl_label = 'EngineNode'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "SHUTDOWN",
"DEBUG_SERVER",
"SHOW_CONSOLE",
"SHOW_ONSCREENTEXT",

            ]        
    outputsockets=[
             
            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        SHUTDOWN = self.inputs.new('NodeTreeBOOL', "SHUTDOWN")
        
        SHUTDOWN.value = 0

        DEBUG_SERVER = self.inputs.new('NodeTreeBOOL', "DEBUG_SERVER")
        
        DEBUG_SERVER.value = 0

        SHOW_CONSOLE = self.inputs.new('NodeTreeBOOL', "SHOW_CONSOLE")
        
        SHOW_CONSOLE.value = 0

        SHOW_ONSCREENTEXT = self.inputs.new('NodeTreeBOOL', "SHOW_ONSCREENTEXT")
        
        SHOW_ONSCREENTEXT.value = 1

        try:
            EngineNode_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'EngineNode',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'EngineNode',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'EngineNode',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        try:
            EngineNode_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            EngineNode_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return EngineNode_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "SHUTDOWN" not in keys:
            SHUTDOWN = self.inputs.new('NodeTreeBOOL', "SHUTDOWN")

        if "DEBUG_SERVER" not in keys:
            DEBUG_SERVER = self.inputs.new('NodeTreeBOOL', "DEBUG_SERVER")

        if "SHOW_CONSOLE" not in keys:
            SHOW_CONSOLE = self.inputs.new('NodeTreeBOOL', "SHOW_CONSOLE")

        if "SHOW_ONSCREENTEXT" not in keys:
            SHOW_ONSCREENTEXT = self.inputs.new('NodeTreeBOOL', "SHOW_ONSCREENTEXT")

        keys = self.outputs.keys()

# Derived from the Node base type.
class IfNode(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''If-Condition'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'IfNode'
    # Label for nice name display
    bl_label = 'If node'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    FUNC_items = [
        ("EQ", "==", "equals"),
        ("GT", ">", "greater than"),
        ("GE", ">=", "greater equals"),
        ("LT", "<", "less than"),
        ("LE", "<=", "less equals"),
        ("NOT", "!=", "not equals"),

    ]
    FUNC = bpy.props.EnumProperty(description="null", items=FUNC_items, default="EQ")
    
    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "a",
"b",

            ]        
    outputsockets=[
             "true",
"false",

            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        a = self.inputs.new('NodeTreeSTRING', "a")

        b = self.inputs.new('NodeTreeSTRING', "b")

        true=self.outputs.new('NodeTreeBOOL', "true")
        
        false=self.outputs.new('NodeTreeBOOL', "false")
        
        try:
            IfNode_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'IfNode',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'IfNode',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'IfNode',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop(self, "FUNC")

        try:
            IfNode_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop(self, "FUNC")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            IfNode_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return IfNode_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "a" not in keys:
            a = self.inputs.new('NodeTreeSTRING', "a")

        if "b" not in keys:
            b = self.inputs.new('NodeTreeSTRING', "b")

        keys = self.outputs.keys()
      
        if "true" not in keys:
            true=self.outputs.new('NodeTreeBOOL', "true")
        
        if "false" not in keys:
            false=self.outputs.new('NodeTreeBOOL', "false")
        
# Derived from the Node base type.
class SoundNode(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''Select Sound'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'SoundNode'
    # Label for nice name display
    bl_label = 'Sound Node'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    FILEP = bpy.props.StringProperty(
        name="FILEP"
        ,default=""
        ,subtype="FILE_PATH"
        ,maxlen=0
        ,description="The NODE"
        
        )
    
    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "ENABLED",

            ]        
    outputsockets=[
             "sound",

            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        ENABLED = self.inputs.new('NodeTreeBOOL', "ENABLED")

        sound=self.outputs.new('NodeTreeSTRING', "sound")
        
        try:
            SoundNode_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'SoundNode',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'SoundNode',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'SoundNode',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop(self, "FILEP")

        try:
            SoundNode_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop(self, "FILEP")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            SoundNode_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return SoundNode_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "ENABLED" not in keys:
            ENABLED = self.inputs.new('NodeTreeBOOL', "ENABLED")

        keys = self.outputs.keys()
      
        if "sound" not in keys:
            sound=self.outputs.new('NodeTreeSTRING', "sound")
        
# Derived from the Node base type.
class JoystickNode(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''null'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'JoystickNode'
    # Label for nice name display
    bl_label = 'JoystickNode'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    deathZoneMin = bpy.props.IntProperty(
        name="deathZoneMin"

        ,default=-1000
        
        ,subtype="NONE"
     
        ,description="no desc"

        )

    deathZoneMax = bpy.props.IntProperty(
        name="deathZoneMax"

        ,default=1000
        
        ,subtype="NONE"
     
        ,description="no desc"

        )
  
    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "UPDATE",
"joystickNr",

            ]        
    outputsockets=[
             "IS_ACTIVE",
"AXIS1",
"AXIS2",
"AXIS1_REL",
"AXIS2_REL",
"AXIS3",
"AXIS4",
"AXIS3_REL",
"AXIS4_REL",
"LEFT",
"RIGHT",
"UP",
"DOWN",

            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        UPDATE = self.inputs.new('NodeTreeBOOL', "UPDATE")

        joystickNr = self.inputs.new('NodeTreeINT', "joystickNr")

        IS_ACTIVE=self.outputs.new('NodeTreeBOOL', "IS_ACTIVE")
        
        AXIS1=self.outputs.new('NodeTreeFLOAT', "AXIS1")
        
        AXIS2=self.outputs.new('NodeTreeFLOAT', "AXIS2")
        
        AXIS1_REL=self.outputs.new('NodeTreeFLOAT', "AXIS1_REL")
        
        AXIS2_REL=self.outputs.new('NodeTreeFLOAT', "AXIS2_REL")
        
        AXIS3=self.outputs.new('NodeTreeFLOAT', "AXIS3")
        
        AXIS4=self.outputs.new('NodeTreeFLOAT', "AXIS4")
        
        AXIS3_REL=self.outputs.new('NodeTreeFLOAT', "AXIS3_REL")
        
        AXIS4_REL=self.outputs.new('NodeTreeFLOAT', "AXIS4_REL")
        
        LEFT=self.outputs.new('NodeTreeBOOL', "LEFT")
        
        RIGHT=self.outputs.new('NodeTreeBOOL', "RIGHT")
        
        UP=self.outputs.new('NodeTreeBOOL', "UP")
        
        DOWN=self.outputs.new('NodeTreeBOOL', "DOWN")
        
        try:
            JoystickNode_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'JoystickNode',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'JoystickNode',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'JoystickNode',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop(self, "deathZoneMin")

        layout.prop(self, "deathZoneMax")

        try:
            JoystickNode_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop(self, "deathZoneMin")

        layout.prop(self, "deathZoneMax")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            JoystickNode_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return JoystickNode_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "UPDATE" not in keys:
            UPDATE = self.inputs.new('NodeTreeBOOL', "UPDATE")

        if "joystickNr" not in keys:
            joystickNr = self.inputs.new('NodeTreeINT', "joystickNr")

        keys = self.outputs.keys()
      
        if "IS_ACTIVE" not in keys:
            IS_ACTIVE=self.outputs.new('NodeTreeBOOL', "IS_ACTIVE")
        
        if "AXIS1" not in keys:
            AXIS1=self.outputs.new('NodeTreeFLOAT', "AXIS1")
        
        if "AXIS2" not in keys:
            AXIS2=self.outputs.new('NodeTreeFLOAT', "AXIS2")
        
        if "AXIS1_REL" not in keys:
            AXIS1_REL=self.outputs.new('NodeTreeFLOAT', "AXIS1_REL")
        
        if "AXIS2_REL" not in keys:
            AXIS2_REL=self.outputs.new('NodeTreeFLOAT', "AXIS2_REL")
        
        if "AXIS3" not in keys:
            AXIS3=self.outputs.new('NodeTreeFLOAT', "AXIS3")
        
        if "AXIS4" not in keys:
            AXIS4=self.outputs.new('NodeTreeFLOAT', "AXIS4")
        
        if "AXIS3_REL" not in keys:
            AXIS3_REL=self.outputs.new('NodeTreeFLOAT', "AXIS3_REL")
        
        if "AXIS4_REL" not in keys:
            AXIS4_REL=self.outputs.new('NodeTreeFLOAT', "AXIS4_REL")
        
        if "LEFT" not in keys:
            LEFT=self.outputs.new('NodeTreeBOOL', "LEFT")
        
        if "RIGHT" not in keys:
            RIGHT=self.outputs.new('NodeTreeBOOL', "RIGHT")
        
        if "UP" not in keys:
            UP=self.outputs.new('NodeTreeBOOL', "UP")
        
        if "DOWN" not in keys:
            DOWN=self.outputs.new('NodeTreeBOOL', "DOWN")
        
# Derived from the Node base type.
class JoystickButton(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''null'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'JoystickButton'
    # Label for nice name display
    bl_label = 'JoystickButton'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    buttonNr = bpy.props.IntProperty(
        name="buttonNr"

        ,default=0
        
        ,subtype="NONE"
     
        ,description="no desc"

        )
  
    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "UPDATE",
"joystickNr",

            ]        
    outputsockets=[
             "IS_DOWN",
"IS_NOT_DOWN",
"IS_PRESSED",
"IS_RELEASED",

            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        UPDATE = self.inputs.new('NodeTreeBOOL', "UPDATE")

        joystickNr = self.inputs.new('NodeTreeINT', "joystickNr")

        IS_DOWN=self.outputs.new('NodeTreeBOOL', "IS_DOWN")
        
        IS_NOT_DOWN=self.outputs.new('NodeTreeBOOL', "IS_NOT_DOWN")
        
        IS_PRESSED=self.outputs.new('NodeTreeBOOL', "IS_PRESSED")
        
        IS_RELEASED=self.outputs.new('NodeTreeBOOL', "IS_RELEASED")
        
        try:
            JoystickButton_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'JoystickButton',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'JoystickButton',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'JoystickButton',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop(self, "buttonNr")

        try:
            JoystickButton_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop(self, "buttonNr")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            JoystickButton_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return JoystickButton_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "UPDATE" not in keys:
            UPDATE = self.inputs.new('NodeTreeBOOL', "UPDATE")

        if "joystickNr" not in keys:
            joystickNr = self.inputs.new('NodeTreeINT', "joystickNr")

        keys = self.outputs.keys()
      
        if "IS_DOWN" not in keys:
            IS_DOWN=self.outputs.new('NodeTreeBOOL', "IS_DOWN")
        
        if "IS_NOT_DOWN" not in keys:
            IS_NOT_DOWN=self.outputs.new('NodeTreeBOOL', "IS_NOT_DOWN")
        
        if "IS_PRESSED" not in keys:
            IS_PRESSED=self.outputs.new('NodeTreeBOOL', "IS_PRESSED")
        
        if "IS_RELEASED" not in keys:
            IS_RELEASED=self.outputs.new('NodeTreeBOOL', "IS_RELEASED")
        
# Derived from the Node base type.
class VehicleNode(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''null'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'VehicleNode'
    # Label for nice name display
    bl_label = 'VehicleNode'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    EngineTorque = bpy.props.FloatProperty(
        name="EngineTorque"

        ,default=330.0
        
        ,subtype="NONE"

        ,unit="NONE"
        ,precision=0
     
        ,description="no desc"

        )

    BreakPower = bpy.props.FloatProperty(
        name="BreakPower"

        ,default=30.0
        
        ,subtype="NONE"

        ,unit="NONE"
        ,precision=2
     
        ,description="no desc"

        )

    RearBreakRatio = bpy.props.FloatProperty(
        name="RearBreakRatio"

        ,default=0.6
        
        ,subtype="NONE"

        ,unit="NONE"
        ,precision=2
     
        ,description="no desc"

        )

    MaxSteeringAngle = bpy.props.FloatProperty(
        name="MaxSteeringAngle"

        ,default=0.23
        
        ,subtype="NONE"

        ,unit="NONE"
        ,precision=2
     
        ,description="no desc"

        )

    RuptorRpm = bpy.props.FloatProperty(
        name="RuptorRpm"

        ,default=6000.0
        
        ,subtype="NONE"

        ,unit="NONE"
        ,precision=0
     
        ,description="no desc"

        )
  
    Type_items = [
        ("ALLWHEEL", "ALLWHEEL", "ALLWHEEL"),
        ("PROPULSION", "PROPULSION", "PROPULSION"),
        ("TRACTION", "TRACTION", "TRACTION"),

    ]
    Type = bpy.props.EnumProperty(description="null", items=Type_items, default="ALLWHEEL")
    
    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "UPDATE",
"FRONT",
"REAR",
"LEFT",
"RIGHT",
"STEER_TIME",
"STEER_VALUE",
"HAND_BRAKE",
"GEAR_UP",
"GEAR_DOWN",
"GEARBOX",

            ]        
    outputsockets=[
             "WHEELS",
"ZROT",
"KMH",
"GEAR",
"RPM",

            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        UPDATE = self.inputs.new('NodeTreeBOOL', "UPDATE")

        FRONT = self.inputs.new('NodeTreeBOOL', "FRONT")

        REAR = self.inputs.new('NodeTreeBOOL', "REAR")

        LEFT = self.inputs.new('NodeTreeBOOL', "LEFT")

        RIGHT = self.inputs.new('NodeTreeBOOL', "RIGHT")

        STEER_TIME = self.inputs.new('NodeTreeFLOAT', "STEER_TIME")

        STEER_VALUE = self.inputs.new('NodeTreeFLOAT', "STEER_VALUE")

        HAND_BRAKE = self.inputs.new('NodeTreeBOOL', "HAND_BRAKE")

        GEAR_UP = self.inputs.new('NodeTreeBOOL', "GEAR_UP")

        GEAR_DOWN = self.inputs.new('NodeTreeBOOL', "GEAR_DOWN")

        GEARBOX = self.inputs.new('NodeTreeBOOL', "GEARBOX")

        WHEELS=self.outputs.new('NodeTreeBOOL', "WHEELS")
        
        ZROT=self.outputs.new('NodeTreeFLOAT', "ZROT")
        
        KMH=self.outputs.new('NodeTreeINT', "KMH")
        
        GEAR=self.outputs.new('NodeTreeINT', "GEAR")
        
        RPM=self.outputs.new('NodeTreeINT', "RPM")
        
        try:
            VehicleNode_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'VehicleNode',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'VehicleNode',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'VehicleNode',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop(self, "Type")

        layout.prop(self, "EngineTorque")

        layout.prop(self, "BreakPower")

        layout.prop(self, "RearBreakRatio")

        layout.prop(self, "MaxSteeringAngle")

        layout.prop(self, "RuptorRpm")

        try:
            VehicleNode_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop(self, "Type")

        layout.prop(self, "EngineTorque")

        layout.prop(self, "BreakPower")

        layout.prop(self, "RearBreakRatio")

        layout.prop(self, "MaxSteeringAngle")

        layout.prop(self, "RuptorRpm")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            VehicleNode_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return VehicleNode_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "UPDATE" not in keys:
            UPDATE = self.inputs.new('NodeTreeBOOL', "UPDATE")

        if "FRONT" not in keys:
            FRONT = self.inputs.new('NodeTreeBOOL', "FRONT")

        if "REAR" not in keys:
            REAR = self.inputs.new('NodeTreeBOOL', "REAR")

        if "LEFT" not in keys:
            LEFT = self.inputs.new('NodeTreeBOOL', "LEFT")

        if "RIGHT" not in keys:
            RIGHT = self.inputs.new('NodeTreeBOOL', "RIGHT")

        if "STEER_TIME" not in keys:
            STEER_TIME = self.inputs.new('NodeTreeFLOAT', "STEER_TIME")

        if "STEER_VALUE" not in keys:
            STEER_VALUE = self.inputs.new('NodeTreeFLOAT', "STEER_VALUE")

        if "HAND_BRAKE" not in keys:
            HAND_BRAKE = self.inputs.new('NodeTreeBOOL', "HAND_BRAKE")

        if "GEAR_UP" not in keys:
            GEAR_UP = self.inputs.new('NodeTreeBOOL', "GEAR_UP")

        if "GEAR_DOWN" not in keys:
            GEAR_DOWN = self.inputs.new('NodeTreeBOOL', "GEAR_DOWN")

        if "GEARBOX" not in keys:
            GEARBOX = self.inputs.new('NodeTreeBOOL', "GEARBOX")

        keys = self.outputs.keys()
      
        if "WHEELS" not in keys:
            WHEELS=self.outputs.new('NodeTreeBOOL', "WHEELS")
        
        if "ZROT" not in keys:
            ZROT=self.outputs.new('NodeTreeFLOAT', "ZROT")
        
        if "KMH" not in keys:
            KMH=self.outputs.new('NodeTreeINT', "KMH")
        
        if "GEAR" not in keys:
            GEAR=self.outputs.new('NodeTreeINT', "GEAR")
        
        if "RPM" not in keys:
            RPM=self.outputs.new('NodeTreeINT', "RPM")
        
# Derived from the Node base type.
class VehicleGearbox(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''null'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'VehicleGearbox'
    # Label for nice name display
    bl_label = 'VehicleGearbox'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    automatic = bpy.props.BoolProperty(
        name="automatic"
        
        ,subtype="NONE"
     
        ,description="no desc"

        )

    shiftTime = bpy.props.FloatProperty(
        name="shiftTime"

        ,default=0.21
        
        ,subtype="NONE"

        ,unit="NONE"
        ,precision=2
     
        ,description="no desc"

        )

    reverseRatio = bpy.props.FloatProperty(
        name="reverseRatio"

        ,default=-11.83
        
        ,subtype="NONE"

        ,unit="NONE"
        ,precision=2
     
        ,description="no desc"

        )
  
    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             
            ]        
    outputsockets=[
             "VEHICLE",
"GEARS",

            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        VEHICLE=self.outputs.new('NodeTreeBOOL', "VEHICLE")
        
        GEARS=self.outputs.new('NodeTreeBOOL', "GEARS")
        
        try:
            VehicleGearbox_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'VehicleGearbox',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'VehicleGearbox',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'VehicleGearbox',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop(self, "automatic")

        layout.prop(self, "shiftTime")

        layout.prop(self, "reverseRatio")

        try:
            VehicleGearbox_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop(self, "automatic")

        layout.prop(self, "shiftTime")

        layout.prop(self, "reverseRatio")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            VehicleGearbox_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return VehicleGearbox_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
      
        keys = self.outputs.keys()
      
        if "VEHICLE" not in keys:
            VEHICLE=self.outputs.new('NodeTreeBOOL', "VEHICLE")
        
        if "GEARS" not in keys:
            GEARS=self.outputs.new('NodeTreeBOOL', "GEARS")
        
# Derived from the Node base type.
class VehicleGear(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''null'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'VehicleGear'
    # Label for nice name display
    bl_label = 'VehicleGear'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    gearNr = bpy.props.IntProperty(
        name="gearNr"

        ,default=1
        
        ,subtype="NONE"
     
        ,description="no desc"

        )

    ratio = bpy.props.FloatProperty(
        name="ratio"

        ,default=9.31
        
        ,subtype="NONE"

        ,unit="NONE"
        ,precision=2
     
        ,description="no desc"

        )

    rpmLow = bpy.props.FloatProperty(
        name="rpmLow"

        ,default=2000.0
        
        ,subtype="NONE"

        ,unit="NONE"
        ,precision=0
     
        ,description="no desc"

        )

    rpmHigh = bpy.props.FloatProperty(
        name="rpmHigh"

        ,default=3000.0
        
        ,subtype="NONE"

        ,unit="NONE"
        ,precision=0
     
        ,description="no desc"

        )
  
    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "GEARBOX",

            ]        
    outputsockets=[
             
            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        GEARBOX = self.inputs.new('NodeTreeBOOL', "GEARBOX")

        try:
            VehicleGear_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'VehicleGear',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'VehicleGear',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'VehicleGear',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop(self, "gearNr")

        layout.prop(self, "ratio")

        layout.prop(self, "rpmLow")

        layout.prop(self, "rpmHigh")

        try:
            VehicleGear_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop(self, "gearNr")

        layout.prop(self, "ratio")

        layout.prop(self, "rpmLow")

        layout.prop(self, "rpmHigh")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            VehicleGear_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return VehicleGear_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "GEARBOX" not in keys:
            GEARBOX = self.inputs.new('NodeTreeBOOL', "GEARBOX")

        keys = self.outputs.keys()

# Derived from the Node base type.
class VehicleWheel(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''null'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'VehicleWheel'
    # Label for nice name display
    bl_label = 'VehicleWheel'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    wheelObject = bpy.props.StringProperty(
        name="wheelObject"
        ,default=""
        ,subtype="NONE"
        ,maxlen=0
        ,description="The NODE"
        
        )
    
    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    isFront = bpy.props.BoolProperty(
        name="isFront"
        
        ,subtype="NONE"
     
        ,description="is this wheel front(steering)-wheel?"

        )

    suspensionTravelCm = bpy.props.FloatProperty(
        name="suspensionTravelCm"

        ,default=40.0
        
        ,subtype="NONE"

        ,unit="NONE"
        ,precision=0
     
        ,description="no desc"

        )

    suspensionRestLength = bpy.props.FloatProperty(
        name="suspensionRestLength"

        ,default=0.4
        
        ,subtype="NONE"

        ,unit="NONE"
        ,precision=2
     
        ,description="The current length of the suspension (metres)"

        )

    suspensionStiffness = bpy.props.FloatProperty(
        name="suspensionStiffness"

        ,default=22.0
        
        ,subtype="NONE"

        ,unit="NONE"
        ,precision=2
     
        ,description="no desc"

        )

    friction = bpy.props.FloatProperty(
        name="friction"

        ,default=2.0
        
        ,subtype="NONE"

        ,unit="NONE"
        ,precision=2
     
        ,description="no desc"

        )

    rollInfluence = bpy.props.FloatProperty(
        name="rollInfluence"

        ,default=0.1
        
        ,subtype="NONE"

        ,unit="NONE"
        ,precision=2
     
        ,description="no desc"

        )

    axis = bpy.props.FloatVectorProperty(
        name="axis"

        ,default=(0.0,0.0,0.0)
        
        ,subtype="NONE"

        ,unit="NONE"
        ,precision=2
     
        ,size=3
   
        ,description="no desc"

        )
  
    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "VEHICLE",

            ]        
    outputsockets=[
             
            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        VEHICLE = self.inputs.new('NodeTreeObject', "VEHICLE")

        try:
            VehicleWheel_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'VehicleWheel',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'VehicleWheel',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'VehicleWheel',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop(self, "isFront")

        layout.prop(self, "suspensionTravelCm")

        layout.prop(self, "suspensionRestLength")

        layout.prop(self, "suspensionStiffness")

        layout.prop(self, "friction")

        layout.prop(self, "rollInfluence")

        layout.prop(self, "axis")

        layout.prop_search(self, "wheelObject", bpy.data, "objects", icon="OBJECT_DATA")

        try:
            VehicleWheel_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop(self, "isFront")

        layout.prop(self, "suspensionTravelCm")

        layout.prop(self, "suspensionRestLength")

        layout.prop(self, "suspensionStiffness")

        layout.prop(self, "friction")

        layout.prop(self, "rollInfluence")

        layout.prop(self, "axis")

        layout.prop_search(self, "wheelObject", bpy.data, "objects", icon="OBJECT_DATA")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            VehicleWheel_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return VehicleWheel_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "VEHICLE" not in keys:
            VEHICLE = self.inputs.new('NodeTreeObject', "VEHICLE")

        keys = self.outputs.keys()

# Derived from the Node base type.
class CameraNode(Node, GamekitNode):
    # === Basics ===
    # Description string
    '''Select Camera'''
    # Optional identifier string. If not explicitly defined, the python class name is used.
    bl_idname = 'CameraNode'
    # Label for nice name display
    bl_label = 'Camera Node'
    # Icon identifier
    bl_icon = 'SOUND'

    # === Custom Properties ===
    # These work just like custom properties in ID data blocks
    # Extensive information can be found under
    # http://wiki.blender.org/index.php/Doc:2.6/Manual/Extensions/Python/Properties

    # subtypes:
    # StringProperty: , , , , , ]

    CAMERA_OBJ = bpy.props.StringProperty(
        name="CAMERA_OBJ"
        ,default=""
        ,subtype="NONE"
        ,maxlen=0
        ,description="The NODE"
        
        )
    
    # FloatTypes: , , , , , , , 
    # FloatUnits: , , , , , , , 
    #FloatVectorType , , , , , , , , , , , , 

    printDebug = bpy.props.BoolProperty()

    inputsockets=[
             "UPDATE",
"CENTER_OBJ",
"CENTER_POSITION",
"REL_X",
"REL_Y",
"REL_Z",
"TARGET",
"INITIAL_PITCH",
"MIN_PITCH",
"MAX_PITCH",
"INITIAL_ROLL",
"MIN_ROLL",
"MAX_ROLL",
"KEEP_DISTANCE",
"MIN_Z",
"MAX_Z",
"AVOID_BLOCKING",
"BLOCKING_RADIUS",
"STIFNESS",
"DAMPING",

            ]        
    outputsockets=[
             "CURRENT_ROLL",
"CURRENT_PITCH",

            ]

    NEW_IN_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    NEW_OUT_SOCKETS = bpy.props.CollectionProperty(type=bpy.types.SocketGroup)

    PRIORITY = bpy.props.IntProperty(default=0)
    STATUS = bpy.props.StringProperty(default="")
    
    def getInputs(self, context):
        result = []
        for insock in self.NEW_IN_SOCKETS:
            result.append((insock.name,insock.name,insock.name))
        return result

    def getOutputs(self, context):
        result = []
        for outsock in self.NEW_OUT_SOCKETS:
            result.append((outsock.name,outsock.name,outsock.name))
        return result

    inputSockets = bpy.props.EnumProperty(items=getInputs)
    outputSockets = bpy.props.EnumProperty(items=getOutputs)   

    # === Optional Functions ===
    # Initialization function, called when a new node is created.
    # This is the most common place to create the sockets for a node, as shown below.
    # NOTE: this is not the same as the standard __init__ function in Python, which is
    #       a purely internal Python method and unknown to the node system!
    def init(self, context):
        print("init node:"+self.name+" contextype:"+str(type(context)))
        bpNode_tree = BPointer.create(self.id_data)
        node_tree = bpNode_tree.get()
        # create a pointer for this node for further usage. just that we have a bpid that we can use
        bpNode = BPointer.create(self) 

        self.PRIORITY = 0
        
        UPDATE = self.inputs.new('NodeTreeBOOL', "UPDATE")

        CENTER_OBJ = self.inputs.new('NodeTreeObject', "CENTER_OBJ")

        CENTER_POSITION = self.inputs.new('NodeTreeVec3', "CENTER_POSITION")

        REL_X = self.inputs.new('NodeTreeFLOAT', "REL_X")
        
        REL_X.value = 0

        REL_Y = self.inputs.new('NodeTreeFLOAT', "REL_Y")
        
        REL_Y.value = 0

        REL_Z = self.inputs.new('NodeTreeFLOAT', "REL_Z")
        
        REL_Z.value = 0

        TARGET = self.inputs.new('NodeTreeObject', "TARGET")

        INITIAL_PITCH = self.inputs.new('NodeTreeFLOAT', "INITIAL_PITCH")
        
        INITIAL_PITCH.value = 45.0

        MIN_PITCH = self.inputs.new('NodeTreeFLOAT', "MIN_PITCH")

        MAX_PITCH = self.inputs.new('NodeTreeFLOAT', "MAX_PITCH")
        
        MAX_PITCH.value = 80.0

        INITIAL_ROLL = self.inputs.new('NodeTreeFLOAT', "INITIAL_ROLL")
        
        INITIAL_ROLL.value = 0

        MIN_ROLL = self.inputs.new('NodeTreeFLOAT', "MIN_ROLL")
        
        MIN_ROLL.value = -180

        MAX_ROLL = self.inputs.new('NodeTreeFLOAT', "MAX_ROLL")
        
        MAX_ROLL.value = 180

        KEEP_DISTANCE = self.inputs.new('NodeTreeBOOL', "KEEP_DISTANCE")
        
        KEEP_DISTANCE.value = 1

        MIN_Z = self.inputs.new('NodeTreeFLOAT', "MIN_Z")
        
        MIN_Z.value = 0

        MAX_Z = self.inputs.new('NodeTreeFLOAT', "MAX_Z")
        
        MAX_Z.value = 10000

        AVOID_BLOCKING = self.inputs.new('NodeTreeBOOL', "AVOID_BLOCKING")
        
        AVOID_BLOCKING.value = 0

        BLOCKING_RADIUS = self.inputs.new('NodeTreeFLOAT', "BLOCKING_RADIUS")
        
        BLOCKING_RADIUS.value = 0.3

        STIFNESS = self.inputs.new('NodeTreeFLOAT', "STIFNESS")
        
        STIFNESS.value = 0.8

        DAMPING = self.inputs.new('NodeTreeFLOAT', "DAMPING")
        
        DAMPING.value = 0.3

        CURRENT_ROLL=self.outputs.new('NodeTreeVec3', "CURRENT_ROLL")
        
        CURRENT_PITCH=self.outputs.new('NodeTreeVec3', "CURRENT_PITCH")
        
        try:
            CameraNode_init(self,context)
        except:
            pass
        
        try:
            logic = runtimedata.RuntimeData.runtime.addElement(self,'CameraNode',"nocatyet")
            if logic:
                ntLogic = node_tree.logic
                logic.startup({"nodetree":ntLogic})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())

    # Copy function to initialize a copied node from an existing one.
    def copy(self, node):
        try:
#             logic = runtimedata.RuntimeData.runtime.addElement(self,'CameraNode',"nocatyet")
            print("COPY COPY")
            print("COPY COPY")
            print("SELF:"+str(self.name))
            print("OTHER:"+str(node.name))
            
            self.bpid=-1
            #create a bpointer
            bpNode = BPointer.create(self) 
            
            if bpy.data.worlds[0].gk_nodetree_debugmode:
                return
            
            logic = runtimedata.RuntimeData.runtime.addElement(self,'CameraNode',"nocatyet")
            if logic:
                node_tree = BPointer.getByID(self.id_data.bpid)
                
                logic.startup({"nodetree":node_tree})
                
            print("ADDED ELEMENT "+self.name+" to runtime")
        except:
            print("Something went wrong adding element to runtime")
            print(traceback.format_exc())
            
    # Free function to clean up on removal.
    def free(self):
        print("Removing node ", self, ", Goodbye!")
        try:
            logic = runtimedata.RuntimeData.runtime.removeElement(self)
            print("removed ELEMENT "+self.name+" from runtime")
        except:
            print("Something went wrong removing element to runtime")
            print(traceback.format_exc())
        
    # Additional buttons displayed on the node.
    def draw_buttons(self, context, layout):
        if bpy.data.worlds[0].gk_nodetree_debugmode and self.STATUS!="":
            layout.prop(self,"STATUS",text="Status:")
            
        layout.label(self.bl_idname)

        layout.prop_search(self, "CAMERA_OBJ", bpy.data, "cameras", icon="OUTLINER_DATA_CAMERA")

        try:
            CameraNode_draw_buttons(self,context,layout)
        except:
            pass
        if self.cover_mode:
            row = layout.row()
            row.template_icon_view(self, "my_previews")   

    # Detail buttons in the sidebar.
    # If this function is not defined, the draw_buttons function is used instead
    def draw_buttons_ext(self, context, layout):
        layout.label("Node settings")
        #layout.prop(self, "myFloatProperty")
        # myStringProperty button will only be visible in the sidebar
        layout.prop(self,"PRIORITY")
        layout.prop(self,"enabled__",text="node enabled?")

        layout.prop_search(self, "CAMERA_OBJ", bpy.data, "cameras", icon="OUTLINER_DATA_CAMERA")

        space = context.space_data
        node_tree = space.node_tree

        layout.operator("gamekit.enable_nodes", text="enable nodes").enableMode=True
        layout.operator("gamekit.enable_nodes", text="disable nodes").enableMode=False

        layout.separator()
        
        layout.prop(node_tree,"show_options")
        if (node_tree.show_options):
            layout.operator("gamekit.addsocket")
            layout.separator()
            layout.prop(self,"inputSockets")
            layout.operator("gamekit.removesocket","remove input-socket").isInputSocket=True
            layout.separator()
            layout.prop(self,"outputSockets")
            layout.operator("gamekit.removesocket","remove output-socket").isInputSocket=False
            row = layout.row()
            row.prop(self,"cover_mode")
            row = layout.row()
            row.template_icon_view(self, "my_previews")
            row = layout.row()
            row.prop(self,"my_previews")
            layout.prop(self,"printDebug")         
                        
        try:
            CameraNode_draw_buttons_ext(self,context,layout)
        except:
            pass 

    # Optional: custom label
    # Explicit user label overrides this, but here we can define a label dynamically
    def draw_label(self):

        if self.label!="":
            return self.label
        
        try: # custom label
            return CameraNode_draw_label(self)
        except:
            pass        
        
        if hasattr(self,"NAME"):
            return self.NAME
        else:
            return self.name
        
    def doUpdate(self):
        for inputSocket in self.inputs:
            if inputSocket.name not in self.inputsockets and inputSocket.name not in self.NEW_IN_SOCKETS:
                if hasattr(self,"extInputs"):
                    found=False
                    for elem in self.extInputs:
                        if elem.extName == inputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.inputs.remove(inputSocket)
                print("Remove InSocket:"+inputSocket.name)
                
        for outputSocket in self.outputs:
            if outputSocket.name not in self.outputsockets and outputSocket.name not in self.NEW_OUT_SOCKETS:
                if hasattr(self,"extOutputs"):
                    found=False
                    for elem in self.extOutputs:
                        if elem.extName == outputSocket.name:
                            found = True
                    
                    if found:
                        continue 

                self.outputs.remove(outputSocket)
                print("Remove InSocket:"+outputSocket.name)

        keys = self.inputs.keys()
        
        if "UPDATE" not in keys:
            UPDATE = self.inputs.new('NodeTreeBOOL', "UPDATE")

        if "CENTER_OBJ" not in keys:
            CENTER_OBJ = self.inputs.new('NodeTreeObject', "CENTER_OBJ")

        if "CENTER_POSITION" not in keys:
            CENTER_POSITION = self.inputs.new('NodeTreeVec3', "CENTER_POSITION")

        if "REL_X" not in keys:
            REL_X = self.inputs.new('NodeTreeFLOAT', "REL_X")

        if "REL_Y" not in keys:
            REL_Y = self.inputs.new('NodeTreeFLOAT', "REL_Y")

        if "REL_Z" not in keys:
            REL_Z = self.inputs.new('NodeTreeFLOAT', "REL_Z")

        if "TARGET" not in keys:
            TARGET = self.inputs.new('NodeTreeObject', "TARGET")

        if "INITIAL_PITCH" not in keys:
            INITIAL_PITCH = self.inputs.new('NodeTreeFLOAT', "INITIAL_PITCH")

        if "MIN_PITCH" not in keys:
            MIN_PITCH = self.inputs.new('NodeTreeFLOAT', "MIN_PITCH")

        if "MAX_PITCH" not in keys:
            MAX_PITCH = self.inputs.new('NodeTreeFLOAT', "MAX_PITCH")

        if "INITIAL_ROLL" not in keys:
            INITIAL_ROLL = self.inputs.new('NodeTreeFLOAT', "INITIAL_ROLL")

        if "MIN_ROLL" not in keys:
            MIN_ROLL = self.inputs.new('NodeTreeFLOAT', "MIN_ROLL")

        if "MAX_ROLL" not in keys:
            MAX_ROLL = self.inputs.new('NodeTreeFLOAT', "MAX_ROLL")

        if "KEEP_DISTANCE" not in keys:
            KEEP_DISTANCE = self.inputs.new('NodeTreeBOOL', "KEEP_DISTANCE")

        if "MIN_Z" not in keys:
            MIN_Z = self.inputs.new('NodeTreeFLOAT', "MIN_Z")

        if "MAX_Z" not in keys:
            MAX_Z = self.inputs.new('NodeTreeFLOAT', "MAX_Z")

        if "AVOID_BLOCKING" not in keys:
            AVOID_BLOCKING = self.inputs.new('NodeTreeBOOL', "AVOID_BLOCKING")

        if "BLOCKING_RADIUS" not in keys:
            BLOCKING_RADIUS = self.inputs.new('NodeTreeFLOAT', "BLOCKING_RADIUS")

        if "STIFNESS" not in keys:
            STIFNESS = self.inputs.new('NodeTreeFLOAT', "STIFNESS")

        if "DAMPING" not in keys:
            DAMPING = self.inputs.new('NodeTreeFLOAT', "DAMPING")

        keys = self.outputs.keys()
      
        if "CURRENT_ROLL" not in keys:
            CURRENT_ROLL=self.outputs.new('NodeTreeVec3', "CURRENT_ROLL")
        
        if "CURRENT_PITCH" not in keys:
            CURRENT_PITCH=self.outputs.new('NodeTreeVec3', "CURRENT_PITCH")
        
### Node Categories ###
# Node categories are a python system for automatically
# extending the Add menu, toolbar panels and search operator.
# For more examples see release/scripts/startup/nodeitems_builtins.py

import nodeitems_utils
from nodeitems_utils import NodeCategory, NodeItem

# our own base class with an appropriate poll function,
# so the categories only show up in our own tree type
class GamekitCategory(NodeCategory):
    @classmethod
    def poll(cls, context):
        return context.space_data.tree_type == 'Gamekit'

# all categories in a list
Gamekit_categories = [

    # identifier, label, items list
    GamekitCategory("physics", "physics", items=[
        # our basic node
        
        NodeItem("PickRayNode"),
        
        NodeItem("CharacterNode"),
        
        NodeItem("CollisionNode"),
        
        NodeItem("VehicleNode"),
        
        NodeItem("VehicleGearbox"),
        
        NodeItem("VehicleGear"),
        
        NodeItem("VehicleWheel"),
        
        ]),

    # identifier, label, items list
    GamekitCategory("temp", "temp", items=[
        # our basic node
        
        NodeItem("TestNode"),
        
        ]),

    # identifier, label, items list
    GamekitCategory("misc", "misc", items=[
        # our basic node
        
        NodeItem("MessageSend"),
        
        NodeItem("MessageGet"),
        
        NodeItem("NoOp"),
        
        NodeItem("PrintNode"),
        
        ]),

    # identifier, label, items list
    GamekitCategory("manipulation", "manipulation", items=[
        # our basic node
        
        NodeItem("ObjectManipulator"),
        
        NodeItem("MotionNode"),
        
        NodeItem("Property"),
        
        NodeItem("PropertyGet"),
        
        NodeItem("DeltaNode"),
        
        ]),

    # identifier, label, items list
    GamekitCategory("sequence", "sequence", items=[
        # our basic node
        
        NodeItem("Sequence"),
        
        NodeItem("SeqFinished"),
        
        NodeItem("SeqTime"),
        
        ]),

    # identifier, label, items list
    GamekitCategory("input", "input", items=[
        # our basic node
        
        NodeItem("MouseNode"),
        
        NodeItem("KeyNode"),
        
        NodeItem("MouseButton"),
        
        NodeItem("JoystickNode"),
        
        NodeItem("JoystickButton"),
        
        ]),

    # identifier, label, items list
    GamekitCategory("math", "math", items=[
        # our basic node
        
        NodeItem("BoolNode"),
        
        NodeItem("MathNode"),
        
        NodeItem("VectorDecomp"),
        
        NodeItem("AdditionNode"),
        
        NodeItem("IfNode"),
        
        ]),

    # identifier, label, items list
    GamekitCategory("engine", "engine", items=[
        # our basic node
        
        NodeItem("TimerNode"),
        
        NodeItem("EngineNode"),
        
        ]),

    # identifier, label, items list
    GamekitCategory("scene", "scene", items=[
        # our basic node
        
        NodeItem("ObjectNode"),
        
        NodeItem("ObjectData"),
        
        NodeItem("NodeTreeNode"),
        
        NodeItem("SoundNode"),
        
        NodeItem("CameraNode"),
        
        ]),

    # identifier, label, items list
    GamekitCategory("mobile", "mobile", items=[
        # our basic node
        
        NodeItem("Accelerometer"),
        
        ]),

    # identifier, label, items list
    GamekitCategory("states", "states", items=[
        # our basic node
        
        NodeItem("StateMachine"),
        
        NodeItem("State"),
        
        NodeItem("StateTransition"),
        
        NodeItem("StateMachineRef"),
        
        NodeItem("StateRef"),
        
        NodeItem("StateManipulator"),
        
        ]),

    # identifier, label, items list
    GamekitCategory("ui", "ui", items=[
        # our basic node
        
        NodeItem("TemplaterNode"),
        
        NodeItem("ScreenAction"),
        
        NodeItem("Element"),
        
        ]),

    # identifier, label, items list
    GamekitCategory("animation", "animation", items=[
        # our basic node
        
        NodeItem("AnimationDefinition"),
        
        NodeItem("AnimationPlayer"),
        
        NodeItem("AnimationTrigger"),
        
        ]),

    # identifier, label, items list
    GamekitCategory("filesystem", "filesystem", items=[
        # our basic node
        
        NodeItem("FileNode"),
        
        ]),

    # identifier, label, items list
    GamekitCategory("lua", "lua", items=[
        # our basic node
        
        NodeItem("LuaNode"),
        
        ]),

    # identifier, label, items list
    GamekitCategory("types", "types", items=[
        # our basic node
        
        NodeItem("TypeColor"),
        
        NodeItem("TypeInt"),
        
        NodeItem("TypeFloat"),
        
        NodeItem("TypeBool"),
        
        ]),

    # identifier, label, items list
    GamekitCategory("pbs", "pbs", items=[
        # our basic node
        
        NodeItem("PBSMaterial"),
        
        NodeItem("PBSSlot"),
        
        NodeItem("PBSTex_Albedo"),
        
        NodeItem("PBSTex_Env"),
        
        NodeItem("PBSTex_Normal"),
        
        NodeItem("PBSTex_F0"),
        
        ]),

GamekitCategory("blender","blender", items=[
   NodeItem("NodeFrame")                                                                       
]),                                                                                                                                                            
                   
    ]

#custom tom
# this code-hooks will be inserted in the generated tree-file

@persistent
def load_handler(dummy):
    print("Custom Loadhandler", bpy.data.filepath)
#     startup()
    
bpy.app.handlers.load_post.append(load_handler)

# NODE_FUNCS = {}
# NODE_CTX = {}
# UPDATE_NODES = []
# 
# def getNodeCTX(node):
#     global NODE_CTX
#     
#     if node not in NODE_CTX:
#         NODE_CTX[node]={}
#         
#     return NODE_CTX  
# 
# # iterate over all nodes and check if there is a startup-hook-set
# def startup():
#     global NODE_FUNCS
#     global UPDATE_NODES
#      
#     for nodetree in bpy.data.node_groups:
#         if nodetree.rna_type.identifier=="Gamekit":
#             for node in nodetree.nodes:
#                 nodetype = node.rna_type.identifier
#                 try:
#                     funcs = NODE_FUNCS[nodetype]
#                     addToUpdateQueue = funcs["startup"](node)
#                     if addToUpdateQueue:
#                         UPDATE_NODES.append(node)
#                 except:
#                     # no startup for this nodetype
#                     pass
                
def NodeTreeNode_draw_buttons(self,context,layout):
    layout.context_pointer_set("node",self)
    layout.operator("gamekit.nodetreenode")

class GamekitNodeTreeNodeOperator(bpy.types.Operator):
    """Tooltip"""
    bl_idname = "gamekit.nodetreenode"
    bl_label = "refresh subtree-sockets"
    bl_space_type = 'NODE_EDITOR'

    @classmethod 
    def poll(cls, context):
        current_node = context.active_node
        current_type = current_node.bl_idname
        return True
#        return current_type=="NodeTreeNode"

    def execute(self, context):
        nodetree = context.space_data.node_tree
        #current_node = context.active_node
        current_node = context.node
        current_type = current_node.bl_idname
        
        if current_node.nodetree=='':
            print ("NO NODETREE SELECTED!")
            return {'FINISHED'}
        
        if current_node.nodetree==current_node.currentTree:
            print("nothing to do")
            return {'FINISHED'}
        
        current_node.currentTree = current_node.nodetree

        #clear the sockets currently added from another nodetree
        for iS in current_node.extInputs:
            current_node.inputs.remove(current_node.inputs[iS.extName])
        current_node.extInputs.clear()
        for oS in current_node.extOutputs:
            current_node.outputs.remove(current_node.outputs[oS.extName])
        current_node.extOutputs.clear()
        
        # get the target-nodetree which is include via nodetreenode
        targetNT = bpy.data.node_groups[current_node.nodetree]
        # get all input and output IO-sockets
        for node in targetNT.nodes:
            for iS in node.inputs:
                try:
                    if iS.isIOSocket:
                        print("ioSock:" + iS.name);
                        ioSock = current_node.extInputs.add()
                        ioSock.name = node.name+"|"+iS.name
                        ioSock.extName = iS.ioSocketName
                        if ioSock.extName == "":
                            ioSock.extName = iS.name
                        ioSockElem = current_node.inputs.new(iS.bl_idname,ioSock.extName)
                except:
                    pass
            for oS in node.outputs:
                try:
                    if oS.isIOSocket:
                        ioSock = current_node.extOutputs.add()
                        ioSock.name = node.name+"|"+oS.name
                        ioSock.extName = oS.ioSocketName
                        if ioSock.extName == "":
                            ioSock.extName = oS.name
                        ioSockElem = current_node.outputs.new(oS.bl_idname,ioSock.extName)
                except:
                    pass
 
        return {'FINISHED'}

def PBSTexMaterial_init(self,context):
    # create material
    newMat = bpy.data.materials.new(name="pbs_mat_" + self.name)
    print ("Create material:"+newMat.name)

def PBSTexEnvMap_init(self,context):
    print ("CREATED IMAGE")
    self.tex = bpy.data.textures.new(self.name,type="IMAGE")
    print ("CREATED IMAGE")

def PBSTexEnvMap_draw_buttons(self,context,layout):
    if self.envMap!="":
        try:
            tex = bpy.data.textures[0]
            #image = bpy.data.images[self.envMap]
            layout.template_preview(tex)
        except:
            print("Unknown image:" + self.envMap)
            print(traceback.format_exc())
            pass;
 
def PBSTexEnvMap_draw_buttons_ext(self,context,layout):
    if self.envMap!="":
        try:
            tex = bpy.data.textures[0]
            #image = bpy.data.images[self.envMap]
            layout.template_preview(tex)
        except:
            print("Unknown image:" + self.envMap)
            pass;

def PBSTex_Albedo_ALBEDO_MAP_update(self,context):
    print("ALBEDO UPDATE")
    if self.ALBEDO_MAP!="" and self.ALBEDO_MAP in bpy.data.images:
        image = bpy.data.images[self.ALBEDO_MAP]
        self.PATH = image.filepath
    else:
        print("NO")
        
def PBSTex_Normal_NORMAL_MAP_update(self,context):
    print("ALBEDO UPDATE")
    if self.NORMAL_MAP!="" and self.NORMAL_MAP in bpy.data.images:
        image = bpy.data.images[self.NORMAL_MAP]
        self.PATH = image.filepath
    else: 
        print("NO")     
           
def PBSTex_F0_F0_MAP_update(self,context):
    if self.F0_MAP!="" and self.F0_MAP in bpy.data.images:
        image = bpy.data.images[self.F0_MAP]
        self.PATH = image.filepath 
    else:
        print("NO")   
        
def PBSTex_Env_ENV_MAP_update(self,context):
    print("ALBEDO UPDATE")
    if self.ENV_MAP!="" and self.ENV_MAP in bpy.data.images:
        image = bpy.data.images[self.ENV_MAP]
        self.PATH = image.filepath
    else:
        print("NO")           
        
################### STATE REF - LOGIC #############################

def StateRef_draw_buttons(self,context,layout):
    if bpy.data.worlds[0].gk_nodetree_debugmode:
        row = layout.row()
        row.enabled=False
        row.prop(self,"STM",text="STM:")
        row = layout.row()
        row.enabled=False
        row.prop(self,"STATE",text="State:")  
    else:
        layout.prop(self,"enumSTM",text="STM:")
        layout.prop(self,"enumSTATE",text="State:")  

def StateMachine_draw_buttons(self,context,layout):
    if bpy.data.worlds[0].gk_nodetree_debugmode:
        row = layout.row()
        row.enabled = False
        row.prop(self,"INITIAL_STATE",text="Initial State:")  
    else:
        layout.prop(self,"enumSTATE",text="Initial State:")  
 
def PropertyGet_draw_buttons(self,context,layout):
    if bpy.data.worlds[0].gk_nodetree_debugmode:
        row = layout.row()
        row.enabled = False
        row.prop(self,"NAME",text="Initial State:")  
    else:
        if len(self.inputs["TARGET_OBJ"].links)>0 or self.MANUAL:
            layout.prop(self,"NAME",text="prop:")
        else:
            layout.prop(self,"enumNAME",text="prop:")   

def StateTransition_draw_label(self):
    return self.inputs["FROM"].links[0].from_node.STATE + "=>" +self.outputs["TO"].links[0].to_node.STATE

def StateRef_draw_label(self):
    return self.STM+"."+self.STATE

def AnimationNode_draw_label(self):
    return self.ANIM_NAME;

def AnimationDefinition_draw_buttons(self,context,layout):
    layout.prop(self,"FRAME_CUSTOM")
    if self.FRAME_CUSTOM:
        layout.prop(self,"FRAME_START")
        layout.prop(self,"FRAME_END")

def AnimationDefinition_draw_buttons_ext(self,context,layout):
    layout.prop(self,"FRAME_CUSTOM")
    if self.FRAME_CUSTOM:
        layout.prop(self,"FRAME_START")
        layout.prop(self,"FRAME_END")

def AnimationPlayer_draw_buttons(self,context,layout):
    if bpy.data.worlds[0].gk_nodetree_debugmode:
        row = layout.row()
        row.enabled = False
        row.prop(self,"NAME",text="Initial State:")  
    else:
        layout.prop(self,"enumNAME",text="Anim:")     

def ObjectNode_draw_label(sefl):
    return self.Obj;

def customRegister():
    try:
        bpy.utils.unregister_class(bpy.types.GamekitNodeTreeNodeOperator)    
    except:
        pass    
    bpy.utils.register_class(GamekitNodeTreeNodeOperator)
    
    bpy.types.NodeTreeNode.extInputs=bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    bpy.types.NodeTreeNode.extOutputs=bpy.props.CollectionProperty(type=bpy.types.SocketGroup)
    bpy.types.NodeTreeNode.currentTree=bpy.props.StringProperty()
    
    print("REGISTERED")

def customUnregister():
    bpy.utils.unregister_class(bpy.types.GamekitNodeTreeNodeOperator)
    
def register():
    try:
        bpy.utils.unregister_class(NodeTreeObject)
        bpy.utils.unregister_class(NodeTreeBOOL)
        bpy.utils.unregister_class(NodeTreeSTRING)
        bpy.utils.unregister_class(NodeTreeFLOAT)
        bpy.utils.unregister_class(NodeTreeINT)
        bpy.utils.unregister_class(NodeTreeCOLOR)
        bpy.utils.unregister_class(NodeTreeVec3)
    except:
        pass
    bpy.utils.register_class(NodeTreeObject)
    bpy.utils.register_class(NodeTreeBOOL)
    bpy.utils.register_class(NodeTreeSTRING)
    bpy.utils.register_class(NodeTreeFLOAT)
    bpy.utils.register_class(NodeTreeINT)
    bpy.utils.register_class(NodeTreeCOLOR)
    bpy.utils.register_class(NodeTreeVec3)
    try:
        bpy.utils.unregister_class(Gamekit)
    except:
        pass
    bpy.utils.register_class(Gamekit)
    try:
        bpy.utils.unregister_class(GamekitPanel)
    except:
        pass
    bpy.utils.register_class(GamekitPanel)
    try:
        bpy.utils.unregister_class(GamekitOperator)
    except:
        pass
    bpy.utils.register_class(GamekitOperator)
    try:
        bpy.utils.unregister_class(PickRayNode)
    except:
        pass
    bpy.utils.register_class(PickRayNode)
    try:
        bpy.utils.unregister_class(TestNode)
    except:
        pass
    bpy.utils.register_class(TestNode)
    try:
        bpy.utils.unregister_class(MessageSend)
    except:
        pass
    bpy.utils.register_class(MessageSend)
    try:
        bpy.utils.unregister_class(MessageGet)
    except:
        pass
    bpy.utils.register_class(MessageGet)
    try:
        bpy.utils.unregister_class(ObjectManipulator)
    except:
        pass
    bpy.utils.register_class(ObjectManipulator)
    try:
        bpy.utils.unregister_class(CharacterNode)
    except:
        pass
    bpy.utils.register_class(CharacterNode)
    try:
        bpy.utils.unregister_class(Sequence)
    except:
        pass
    bpy.utils.register_class(Sequence)
    try:
        bpy.utils.unregister_class(SeqFinished)
    except:
        pass
    bpy.utils.register_class(SeqFinished)
    try:
        bpy.utils.unregister_class(SeqTime)
    except:
        pass
    bpy.utils.register_class(SeqTime)
    try:
        bpy.utils.unregister_class(MotionNode)
    except:
        pass
    bpy.utils.register_class(MotionNode)
    try:
        bpy.utils.unregister_class(MouseNode)
    except:
        pass
    bpy.utils.register_class(MouseNode)
    try:
        bpy.utils.unregister_class(BoolNode)
    except:
        pass
    bpy.utils.register_class(BoolNode)
    try:
        bpy.utils.unregister_class(MathNode)
    except:
        pass
    bpy.utils.register_class(MathNode)
    try:
        bpy.utils.unregister_class(TimerNode)
    except:
        pass
    bpy.utils.register_class(TimerNode)
    try:
        bpy.utils.unregister_class(ObjectNode)
    except:
        pass
    bpy.utils.register_class(ObjectNode)
    try:
        bpy.utils.unregister_class(ObjectData)
    except:
        pass
    bpy.utils.register_class(ObjectData)
    try:
        bpy.utils.unregister_class(Accelerometer)
    except:
        pass
    bpy.utils.register_class(Accelerometer)
    try:
        bpy.utils.unregister_class(VectorDecomp)
    except:
        pass
    bpy.utils.register_class(VectorDecomp)
    try:
        bpy.utils.unregister_class(NodeTreeNode)
    except:
        pass
    bpy.utils.register_class(NodeTreeNode)
    try:
        bpy.utils.unregister_class(StateMachine)
    except:
        pass
    bpy.utils.register_class(StateMachine)
    try:
        bpy.utils.unregister_class(State)
    except:
        pass
    bpy.utils.register_class(State)
    try:
        bpy.utils.unregister_class(StateTransition)
    except:
        pass
    bpy.utils.register_class(StateTransition)
    try:
        bpy.utils.unregister_class(StateMachineRef)
    except:
        pass
    bpy.utils.register_class(StateMachineRef)
    try:
        bpy.utils.unregister_class(StateRef)
    except:
        pass
    bpy.utils.register_class(StateRef)
    try:
        bpy.utils.unregister_class(StateManipulator)
    except:
        pass
    bpy.utils.register_class(StateManipulator)
    try:
        bpy.utils.unregister_class(Property)
    except:
        pass
    bpy.utils.register_class(Property)
    try:
        bpy.utils.unregister_class(PropertyGet)
    except:
        pass
    bpy.utils.register_class(PropertyGet)
    try:
        bpy.utils.unregister_class(NoOp)
    except:
        pass
    bpy.utils.register_class(NoOp)
    try:
        bpy.utils.unregister_class(TemplaterNode)
    except:
        pass
    bpy.utils.register_class(TemplaterNode)
    try:
        bpy.utils.unregister_class(ScreenAction)
    except:
        pass
    bpy.utils.register_class(ScreenAction)
    try:
        bpy.utils.unregister_class(Element)
    except:
        pass
    bpy.utils.register_class(Element)
    try:
        bpy.utils.unregister_class(AnimationDefinition)
    except:
        pass
    bpy.utils.register_class(AnimationDefinition)
    try:
        bpy.utils.unregister_class(AnimationPlayer)
    except:
        pass
    bpy.utils.register_class(AnimationPlayer)
    try:
        bpy.utils.unregister_class(AnimationTrigger)
    except:
        pass
    bpy.utils.register_class(AnimationTrigger)
    try:
        bpy.utils.unregister_class(CollisionNode)
    except:
        pass
    bpy.utils.register_class(CollisionNode)
    try:
        bpy.utils.unregister_class(FileNode)
    except:
        pass
    bpy.utils.register_class(FileNode)
    try:
        bpy.utils.unregister_class(LuaNode)
    except:
        pass
    bpy.utils.register_class(LuaNode)
    try:
        bpy.utils.unregister_class(AdditionNode)
    except:
        pass
    bpy.utils.register_class(AdditionNode)
    try:
        bpy.utils.unregister_class(PrintNode)
    except:
        pass
    bpy.utils.register_class(PrintNode)
    try:
        bpy.utils.unregister_class(KeyNode)
    except:
        pass
    bpy.utils.register_class(KeyNode)
    try:
        bpy.utils.unregister_class(MouseButton)
    except:
        pass
    bpy.utils.register_class(MouseButton)
    try:
        bpy.utils.unregister_class(DeltaNode)
    except:
        pass
    bpy.utils.register_class(DeltaNode)
    try:
        bpy.utils.unregister_class(TypeColor)
    except:
        pass
    bpy.utils.register_class(TypeColor)
    try:
        bpy.utils.unregister_class(TypeInt)
    except:
        pass
    bpy.utils.register_class(TypeInt)
    try:
        bpy.utils.unregister_class(TypeFloat)
    except:
        pass
    bpy.utils.register_class(TypeFloat)
    try:
        bpy.utils.unregister_class(TypeBool)
    except:
        pass
    bpy.utils.register_class(TypeBool)
    try:
        bpy.utils.unregister_class(PBSMaterial)
    except:
        pass
    bpy.utils.register_class(PBSMaterial)
    try:
        bpy.utils.unregister_class(PBSSlot)
    except:
        pass
    bpy.utils.register_class(PBSSlot)
    try:
        bpy.utils.unregister_class(PBSTex_Albedo)
    except:
        pass
    bpy.utils.register_class(PBSTex_Albedo)
    try:
        bpy.utils.unregister_class(PBSTex_Env)
    except:
        pass
    bpy.utils.register_class(PBSTex_Env)
    try:
        bpy.utils.unregister_class(PBSTex_Normal)
    except:
        pass
    bpy.utils.register_class(PBSTex_Normal)
    try:
        bpy.utils.unregister_class(PBSTex_F0)
    except:
        pass
    bpy.utils.register_class(PBSTex_F0)
    try:
        bpy.utils.unregister_class(EngineNode)
    except:
        pass
    bpy.utils.register_class(EngineNode)
    try:
        bpy.utils.unregister_class(IfNode)
    except:
        pass
    bpy.utils.register_class(IfNode)
    try:
        bpy.utils.unregister_class(SoundNode)
    except:
        pass
    bpy.utils.register_class(SoundNode)
    try:
        bpy.utils.unregister_class(JoystickNode)
    except:
        pass
    bpy.utils.register_class(JoystickNode)
    try:
        bpy.utils.unregister_class(JoystickButton)
    except:
        pass
    bpy.utils.register_class(JoystickButton)
    try:
        bpy.utils.unregister_class(VehicleNode)
    except:
        pass
    bpy.utils.register_class(VehicleNode)
    try:
        bpy.utils.unregister_class(VehicleGearbox)
    except:
        pass
    bpy.utils.register_class(VehicleGearbox)
    try:
        bpy.utils.unregister_class(VehicleGear)
    except:
        pass
    bpy.utils.register_class(VehicleGear)
    try:
        bpy.utils.unregister_class(VehicleWheel)
    except:
        pass
    bpy.utils.register_class(VehicleWheel)
    try:
        bpy.utils.unregister_class(CameraNode)
    except:
        pass
    bpy.utils.register_class(CameraNode)

    try:
        nodeitems_utils.unregister_node_categories("Gamekit_NODES")
    except:
        pass
    nodeitems_utils.register_node_categories("Gamekit_NODES", Gamekit_categories)
    try:
        customRegister()
        import runtimeMappings
        runtimeMappings.custom_register()
    except:
        print(traceback.format_exc())
        pass 

def unregister():
    nodeitems_utils.unregister_node_categories("Gamekit_NODES")

    bpy.utils.unregister_class(Gamekit)
    bpy.utils.unregister_class(GamekitPanel)
    bpy.utils.unregister_class(GamekitOperator)
    bpy.utils.unregister_class(PickRayNode)
    bpy.utils.unregister_class(TestNode)
    bpy.utils.unregister_class(MessageSend)
    bpy.utils.unregister_class(MessageGet)
    bpy.utils.unregister_class(ObjectManipulator)
    bpy.utils.unregister_class(CharacterNode)
    bpy.utils.unregister_class(Sequence)
    bpy.utils.unregister_class(SeqFinished)
    bpy.utils.unregister_class(SeqTime)
    bpy.utils.unregister_class(MotionNode)
    bpy.utils.unregister_class(MouseNode)
    bpy.utils.unregister_class(BoolNode)
    bpy.utils.unregister_class(MathNode)
    bpy.utils.unregister_class(TimerNode)
    bpy.utils.unregister_class(ObjectNode)
    bpy.utils.unregister_class(ObjectData)
    bpy.utils.unregister_class(Accelerometer)
    bpy.utils.unregister_class(VectorDecomp)
    bpy.utils.unregister_class(NodeTreeNode)
    bpy.utils.unregister_class(StateMachine)
    bpy.utils.unregister_class(State)
    bpy.utils.unregister_class(StateTransition)
    bpy.utils.unregister_class(StateMachineRef)
    bpy.utils.unregister_class(StateRef)
    bpy.utils.unregister_class(StateManipulator)
    bpy.utils.unregister_class(Property)
    bpy.utils.unregister_class(PropertyGet)
    bpy.utils.unregister_class(NoOp)
    bpy.utils.unregister_class(TemplaterNode)
    bpy.utils.unregister_class(ScreenAction)
    bpy.utils.unregister_class(Element)
    bpy.utils.unregister_class(AnimationDefinition)
    bpy.utils.unregister_class(AnimationPlayer)
    bpy.utils.unregister_class(AnimationTrigger)
    bpy.utils.unregister_class(CollisionNode)
    bpy.utils.unregister_class(FileNode)
    bpy.utils.unregister_class(LuaNode)
    bpy.utils.unregister_class(AdditionNode)
    bpy.utils.unregister_class(PrintNode)
    bpy.utils.unregister_class(KeyNode)
    bpy.utils.unregister_class(MouseButton)
    bpy.utils.unregister_class(DeltaNode)
    bpy.utils.unregister_class(TypeColor)
    bpy.utils.unregister_class(TypeInt)
    bpy.utils.unregister_class(TypeFloat)
    bpy.utils.unregister_class(TypeBool)
    bpy.utils.unregister_class(PBSMaterial)
    bpy.utils.unregister_class(PBSSlot)
    bpy.utils.unregister_class(PBSTex_Albedo)
    bpy.utils.unregister_class(PBSTex_Env)
    bpy.utils.unregister_class(PBSTex_Normal)
    bpy.utils.unregister_class(PBSTex_F0)
    bpy.utils.unregister_class(EngineNode)
    bpy.utils.unregister_class(IfNode)
    bpy.utils.unregister_class(SoundNode)
    bpy.utils.unregister_class(JoystickNode)
    bpy.utils.unregister_class(JoystickButton)
    bpy.utils.unregister_class(VehicleNode)
    bpy.utils.unregister_class(VehicleGearbox)
    bpy.utils.unregister_class(VehicleGear)
    bpy.utils.unregister_class(VehicleWheel)
    bpy.utils.unregister_class(CameraNode)
    
    bpy.utils.unregister_class(NodeTreeObject)
    bpy.utils.unregister_class(NodeTreeBOOL)
    bpy.utils.unregister_class(NodeTreeSTRING)
    bpy.utils.unregister_class(NodeTreeFLOAT)
    bpy.utils.unregister_class(NodeTreeINT)
    bpy.utils.unregister_class(NodeTreeCOLOR)
    bpy.utils.unregister_class(NodeTreeVec3)
    try:
        customUnregister()
        import runtimeMappings
        runtimeMappings.custom_unregister()
    except:
        print(traceback.format_exc())
        pass    

if __name__ == "__main__":
    register()
