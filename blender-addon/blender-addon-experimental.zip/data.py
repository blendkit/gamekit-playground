bl_addon_data =
    {
    (2,5,3):
        {
        (0,0,601):
            {
            'binary_name':'ogrekit',
            'api_compatibility':
                {
                31845:{
                    (0,0,601):(995,-1)
                    }
                },
            'binary_urls':
                {
                'linux-32':'<ogrekit 0.0.601 executable URL>',
                'linux-64':'<ogrekit 0.0.601 executable URL>',
                'windows-32':'<ogrekit 0.0.601 executable URL>',
                'windows-64':'<ogrekit 0.0.601 executable URL>',
                'osx-intel':'<ogrekit 0.0.601 executable URL>',
                'osx-ppc':'<ogrekit 0.0.601 executable URL>'
                }
            }
        }
    }